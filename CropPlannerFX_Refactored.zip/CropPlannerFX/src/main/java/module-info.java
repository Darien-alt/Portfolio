module com.planningandrotation.cropplannerfx {
    requires javafx.controls;
    requires javafx.fxml;
    requires java.base;
    requires java.net.http;
    requires org.json;

    opens com.planningandrotation.cropplannerfx to javafx.fxml;
    exports com.planningandrotation.cropplannerfx;
}
