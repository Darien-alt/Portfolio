package com.planningandrotation.cropplannerfx;

import java.io.IOException;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import com.planningandrotation.cropplannerfx.Navigation;
import javafx.application.Platform;
import javafx.scene.control.SplitPane;
import javafx.scene.layout.Pane;

public class PrimaryController {

    @FXML
    private SplitPane mainSplitPane;

    @FXML
    private void initialize() {
        Platform.runLater(() -> {
            // Request focus on the SplitPane or any non-interactive element to clear focus from buttons
            mainSplitPane.requestFocus();
            
            mainSplitPane.setDividerPositions(0.5);
            
            mainSplitPane.getDividers().get(0).positionProperty().addListener((obs, oldPos, newPos) -> {
                // Set the divider back to the fixed position if it changes
                mainSplitPane.setDividerPositions(0.5);
            });
            
            // Set the cursor style of the divider to 'default'
            mainSplitPane.lookupAll(".split-pane-divider").forEach(divider -> {
            divider.setStyle("-fx-cursor: default;");
        });
        });
    }
    
    @FXML
    private void toAddCropLocation() {
        // Use Navigation to switch the scene to secondary.fxml
        Navigation.switchScene("addCropLocation");
    }
    
    @FXML
    private void toManageCrops() {
        // Use Navigation to switch the scene to secondary.fxml
        Navigation.switchScene("ManageCrops");
    }
    
    @FXML 
    private void toPastHarvests(){
        Navigation.switchScene("HarvestedCrops");
    }
    
    @FXML
    private void toWeatherForecast() {
        Navigation.switchScene("WeatherForecast");
    }
    
    @FXML
    private void toAlerts() {
        Navigation.switchScene("Alerts");
    }
    
    @FXML
    private void toSensorData() {
        Navigation.switchScene("SensorData");
    }
    
    @FXML
    private void toPestDisease() {
        Navigation.switchScene("PestandDisease");
    }
    
    public void handleExit() {
        Platform.exit();
    }
    
    
}
