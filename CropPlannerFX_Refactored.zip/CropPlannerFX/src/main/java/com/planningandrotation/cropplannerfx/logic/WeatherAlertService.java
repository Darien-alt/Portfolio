package com.planningandrotation.cropplannerfx.logic;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */


import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;

public class WeatherAlertService {

    private static final String API_KEY = "5a7aca5509a8fc06d33175d0f26d77c2";

    public static String fetchWeatherAlerts(double latitude, double longitude) {
    try {
        // URL to get the weather alerts for the given latitude and longitude
        String alertUrl = String.format("https://api.openweathermap.org/data/2.5/weather?lat=%f&lon=%f&appid=%s", latitude, longitude, API_KEY);
        
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest alertRequest = HttpRequest.newBuilder().uri(URI.create(alertUrl)).build();
        HttpResponse<String> alertResponse = client.send(alertRequest, HttpResponse.BodyHandlers.ofString());

        if (alertResponse.statusCode() == 200) {
            // Parse the alert response
            JSONObject alertJson = new JSONObject(alertResponse.body());
            if (alertJson.has("alerts")) {
                JSONArray alertsArray = alertJson.getJSONArray("alerts");
                StringBuilder alertsBuilder = new StringBuilder();
                for (int i = 0; i < alertsArray.length(); i++) {
                    JSONObject alert = alertsArray.getJSONObject(i);
                    alertsBuilder.append(alert.getString("event")).append(" - ").append(alert.getString("description")).append("\n\n");
                }
                return alertsBuilder.toString();
            } else {
                return "No severe weather alerts for the given location.";
            }
        } else {
            return "Failed to retrieve weather alerts. Please try again.";
        }

    } catch (Exception e) {
        e.printStackTrace();
        return "An error occurred while fetching the weather alerts.";
    }
}
    
}

