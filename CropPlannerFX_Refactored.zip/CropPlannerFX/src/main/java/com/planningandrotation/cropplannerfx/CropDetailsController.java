package com.planningandrotation.cropplannerfx;

import java.io.IOException;
import java.net.URI;
import java.net.URL;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.ButtonBar;
import javafx.scene.control.ButtonType;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;
import org.json.JSONObject;

public class CropDetailsController implements Initializable {

    @FXML
    private Label nameLabel;

    @FXML
    private Label varietyLabel;

    @FXML
    private Label plantingDateLabel;

    @FXML
    private Label harvestDateLabel;

    @FXML
    private Label fertilizationDetailsLabel;

    @FXML
    private Label careNotesLabel;

    @FXML
    private Label avgPriceLabel;

    @FXML
    private Label avgYieldLabel;

    @FXML
    private ImageView cropImageView;

    private Crop selectedCrop;
    
    private UserInputForm userInputForm;

    private Stage mainStage; // Class-level variable to store the Stage reference
    
    public void setUserInputForm(UserInputForm userInputForm) {
        this.userInputForm = userInputForm;
    }

    public void setMainStage(Stage mainStage) {
        this.mainStage = mainStage; // Set the main stage
    }

    @Override
    public void initialize(URL url, ResourceBundle rb) {
        nameLabel.setWrapText(true);
        varietyLabel.setWrapText(true);
        plantingDateLabel.setWrapText(true);
        harvestDateLabel.setWrapText(true);
        fertilizationDetailsLabel.setWrapText(true);
        careNotesLabel.setWrapText(true);
        avgPriceLabel.setWrapText(true);
        avgYieldLabel.setWrapText(true);
    }

    public void setCropDetails(Crop selectedCrop) {
        this.selectedCrop = selectedCrop;

        if (selectedCrop != null) {
            nameLabel.setText(getSafeValue(selectedCrop.getName(), "Not Available"));
            varietyLabel.setText( getSafeValue(selectedCrop.getVariety(), "Not Available"));
            plantingDateLabel.setText(getSafeValue(selectedCrop.getPlantingDate(), "Not Available"));
            harvestDateLabel.setText(getSafeValue(selectedCrop.getHarvestDate(), "Not Available"));
            fertilizationDetailsLabel.setText(getSafeValue(selectedCrop.getFertilizationDetails(), "Not Available"));
            careNotesLabel.setText(getSafeValue(selectedCrop.getCareNotes(), "Not Available"));
            avgPriceLabel.setText("Average Price: " + getSafeValue(String.valueOf(selectedCrop.getAvgMarketPriceLb()), "Not Available"));
            avgYieldLabel.setText("Average Yield: " + getSafeValue(selectedCrop.getAvgYield(), "Not Available"));

            String imagePath = selectedCrop.getImagePath();
            if (imagePath != null && !imagePath.isEmpty()) {
                URL imageUrl = getClass().getResource(imagePath);
                if (imageUrl != null) {
                    Image cropImage = new Image(imageUrl.toString());
                    cropImageView.setImage(cropImage);
                } else {
                    cropImageView.setImage(new Image("/images/default-placeholder.png"));
                }
            } else {
                cropImageView.setImage(new Image("/images/default-placeholder.png"));
            }
        }
    }

    private String getSafeValue(String value, String defaultValue) {
        return value != null && !value.isEmpty() ? value : defaultValue;
    }

    @FXML
private void handleAddCrop() {
    // Confirmation dialog
    Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
    confirmationAlert.setTitle("Add Crop");
    confirmationAlert.setHeaderText("Do you want to add this crop to your growing list?");
    confirmationAlert.setContentText("This crop will be added to your tracked crops.");

    Optional<ButtonType> result = confirmationAlert.showAndWait();
    if (result.isPresent() && result.get() == ButtonType.OK) {
        // If user confirms, proceed to save the crop
        if (selectedCrop != null) {
            boolean success = saveCropForUser(selectedCrop);
            if (success) {
                // Custom success alert with a "Done" button
                Alert successAlert = new Alert(Alert.AlertType.INFORMATION);
                successAlert.setTitle("Success");
                successAlert.setHeaderText("Crop added successfully!");
                ButtonType doneButton = new ButtonType("Done", ButtonBar.ButtonData.OK_DONE);
                successAlert.getButtonTypes().setAll(doneButton);

                Optional<ButtonType> doneResult = successAlert.showAndWait();
                if (doneResult.isPresent() && doneResult.get() == doneButton) {
                    // Navigate back to primary.fxml
                    Navigation.switchScene("primary");
                }
            } else {
                // Show an error dialog if the crop could not be saved
                Alert errorAlert = new Alert(Alert.AlertType.ERROR);
                errorAlert.setTitle("Error");
                errorAlert.setHeaderText(null);
                errorAlert.setContentText("Failed to add crop. Please try again.");
                errorAlert.showAndWait();
            }
        } else {
            // Show an error dialog if no crop is selected
            Alert errorAlert = new Alert(Alert.AlertType.ERROR);
            errorAlert.setTitle("Error");
            errorAlert.setHeaderText(null);
            errorAlert.setContentText("No crop selected.");
            errorAlert.showAndWait();
        }
    }
}

    private boolean saveCropForUser(Crop crop) {
        try {
            String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/user_crops/";

            JSONObject cropDataJson = new JSONObject();
            cropDataJson.put("user_id", UserSession.getInstance().getUserId());
            cropDataJson.put("crop_name", crop.getName());
            cropDataJson.put("variety", crop.getVariety());
            cropDataJson.put("planting_date", crop.getPlantingDate());
            cropDataJson.put("harvest_date", crop.getHarvestDate());
            cropDataJson.put("fertilization_details", crop.getFertilizationDetails());
            cropDataJson.put("care_notes", crop.getCareNotes());
            cropDataJson.put("avg_price", crop.getAvgMarketPriceLb());
            cropDataJson.put("avg_yield", crop.getAvgYield());
            String currentTimestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            cropDataJson.put("created_at", currentTimestamp);
            cropDataJson.put("is_deleted", 0);
            cropDataJson.put("is_harvested", crop.getIsHarvested());

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(cropDataJson.toString()))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 201) {
                return true;
            } else {
                System.out.println("Failed to save crop data. Response code: " + response.statusCode());
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

   @FXML
private void backToRecommendations() {
    try {
        System.out.println("Navigating back to Crop Recommendations");

        FXMLLoader loader = new FXMLLoader(getClass().getResource("CropRecommendations.fxml"));
        Parent cropRecommendationsRoot = loader.load();

        // Get the CropRecommendationsController and set the mainStage and userInputForm
        CropRecommendationsController cropRecommendationsController = loader.getController();

        // Use the existing references to mainStage and userInputForm
        if (mainStage != null) {
            cropRecommendationsController.setMainStage(mainStage); // Set mainStage
        } else {
            System.err.println("Error: mainStage is not set. Cannot proceed.");
            return; // Exit early if mainStage is null
        }

        if (userInputForm != null) {
            cropRecommendationsController.setUserInputForm(userInputForm); // Set userInputForm
        } else {
            System.err.println("Error: UserInputForm is not set. Cannot proceed with recommending crops.");
            return; // Exit early if userInputForm is null
        }

        // Re-populate the recommendations using userInputForm to maintain state
        cropRecommendationsController.recommendCrops(userInputForm);

        // Switch to the Crop Recommendations scene
        Scene scene = new Scene(cropRecommendationsRoot);
        mainStage.setScene(scene);
        mainStage.show();
    } catch (IOException e) {
        System.err.println("Failed to navigate to Crop Recommendations: " + e.getMessage());
        e.printStackTrace();
    }
}
}