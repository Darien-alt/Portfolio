package com.planningandrotation.cropplannerfx.ui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import javafx.stage.Stage;

/**
 * FXML Controller class
 *
 * @author djlan
 */
public class AddCropSensorController implements App.HasMainStage {

    private Stage mainStage;
    private UserInputForm userInputForm;
    
@FXML
private TextField moistureField;

@FXML
private TextField tempField;

@FXML
private TextField soilPhField;

    // Set mainStage method to receive the Stage from App or Navigation class
    public void setMainStage(Stage mainStage) {
        this.mainStage = mainStage;
    }

    // Setter method for UserInputForm
    public void setUserInputForm(UserInputForm userInputForm) {
        this.userInputForm = userInputForm;
    }

   @FXML
private void toCropRecommendations() {
        try {
            // Ensure user input form is available before proceeding
            if (userInputForm == null) {
                System.out.println("UserInputForm is null. Please enter the location data first.");
                return;
            }

            // Validate that all sensor fields are filled in
            if (moistureField.getText().isEmpty()) {
                System.out.println("Soil moisture field is empty. Please enter a valid value.");
                return;
            }
            if (tempField.getText().isEmpty()) {
                System.out.println("Soil temperature field is empty. Please enter a valid value.");
                return;
            }
            if (soilPhField.getText().isEmpty()) {
                System.out.println("Soil pH field is empty. Please enter a valid value.");
                return;
            }

            // If fields are filled, parse and set the sensor data
            try {
                double soilMoisture = Double.parseDouble(moistureField.getText().trim());
                userInputForm.setSoilMoisture(soilMoisture);
            } catch (NumberFormatException e) {
                System.out.println("Invalid soil moisture value. Please enter a valid number.");
                return;
            }

            try {
                double soilTemperature = Double.parseDouble(tempField.getText().trim());
                userInputForm.setSoilTemperature(soilTemperature);
            } catch (NumberFormatException e) {
                System.out.println("Invalid soil temperature value. Please enter a valid number.");
                return;
            }

            try {
                double soilPH = Double.parseDouble(soilPhField.getText().trim());
                userInputForm.setSoilPH(soilPH);
            } catch (NumberFormatException e) {
                System.out.println("Invalid soil pH value. Please enter a valid number.");
                return;
            }

            // Prompt user for minProfitThreshold using a TextInputDialog
            TextInputDialog dialog = new TextInputDialog();
            dialog.setTitle("Minimum Profit Threshold");
            dialog.setHeaderText("Enter Minimum Profit Threshold");
            dialog.setContentText("Please enter the minimum profit threshold:");

            Optional<String> result = dialog.showAndWait();
            if (result.isPresent()) {
                try {
                    double minProfitThreshold = Double.parseDouble(result.get().trim());
                    userInputForm.setMinProfitThreshold(minProfitThreshold);  // Set the threshold in the UserInputForm
                } catch (NumberFormatException e) {
                    System.out.println("Invalid minimum profit threshold value. Please enter a valid number.");
                    return;
                }
            } else {
                System.out.println("No value entered for minimum profit threshold.");
                return; // Exit if no value is entered
            }

            // Save user data using the REST API
            boolean success = UserInputForm.saveUserData(userInputForm);
            if (success) {
                System.out.println("User data saved successfully!");
            } else {
                System.out.println("Failed to save user data. Please try again.");
                return;  // Exit the function if the save fails
            }

            // Load the CropRecommendations.fxml
            FXMLLoader loader = new FXMLLoader(getClass().getResource("CropRecommendations.fxml"));
            Parent root = loader.load();

            // Get the CropRecommendationsController and set the userInputForm
            CropRecommendationsController controller = loader.getController();
            controller.setUserInputForm(userInputForm);  // Set user input form first
            controller.setMainStage(mainStage);  // Set the main stage after setting user input form

            // Set the scene and show it
            Scene scene = new Scene(root);
            mainStage.setScene(scene);
            mainStage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    

    @FXML
    private void backToLocation() {
        Navigation.switchScene("addCropLocation", controller -> {
        AddCropLocationController locationController = (AddCropLocationController) controller;
        locationController.resetFields();  // Clear the fields when navigating back
    });
    }
    
    // Method to reset all sensor fields
    public void resetFields() {
        moistureField.clear();
        tempField.clear();
        soilPhField.clear();
    }
    
}
