package com.planningandrotation.cropplannerfx.ui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.net.URL;
import javafx.scene.control.TextInputDialog;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.VBox;
import javafx.scene.control.Label;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;

public class PestandDiseaseController implements Initializable {

    @FXML
    private VBox pestDiseaseBox;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        int userId = UserSession.getInstance().getUserId();
        
        // Prompt the user to either input sensor data or use the most recent data
        promptForSensorDataChoice(userId);
    }

    private void promptForSensorDataChoice(int userId) {
        Alert alert = new Alert(AlertType.CONFIRMATION);
        alert.setTitle("Sensor Data Input");
        alert.setHeaderText("Choose Sensor Data Input Method");
        alert.setContentText("Would you like to enter new sensor data or use the most recent data?");

        ButtonType inputButton = new ButtonType("Enter Data");
        ButtonType recentButton = new ButtonType("Use Most Recent");

        alert.getButtonTypes().setAll(inputButton, recentButton);

        Optional<ButtonType> result = alert.showAndWait();
        if (result.isPresent()) {
            if (result.get() == inputButton) {
                // Prompt for manual sensor data input
                promptForSensorData();
            } else if (result.get() == recentButton) {
                // Fetch and use most recent sensor data
                useMostRecentSensorData(userId);
            }
        }
    }

        private void promptForSensorData() {
        // Allow user to cancel input
        Double soilTemperature = getSensorValueFromUser("Enter Soil Temperature (°F):");
        if (soilTemperature == null) {
            return; // User cancelled the input, do nothing
        }

        Double soilMoisture = getSensorValueFromUser("Enter Soil Moisture (%):");
        if (soilMoisture == null) {
            return; // User cancelled the input, do nothing
        }

        Double soilPH = getSensorValueFromUser("Enter Soil pH:");
        if (soilPH == null) {
            return; // User cancelled the input, do nothing
        }

        // Call the prediction method using the input values
        predictPestOrDisease(soilTemperature, soilMoisture, soilPH);
    }

private Double getSensorValueFromUser(String prompt) {
    TextInputDialog dialog = new TextInputDialog();
    dialog.setTitle("Sensor Data Input");
    dialog.setHeaderText(null);
    dialog.setContentText(prompt);

    Optional<String> result = dialog.showAndWait();
    if (result.isPresent() && !result.get().isEmpty()) {
        try {
            return Double.parseDouble(result.get());
        } catch (NumberFormatException e) {
            showError("Invalid input. Please enter a valid number.");
            return getSensorValueFromUser(prompt); // Retry input
        }
    } else {
        // User cancelled the dialog or provided an empty input
        return null; // Indicate that the user canceled the input
    }
}

    private void useMostRecentSensorData(int userId) {
    // Fetch all soil sensor data for the given user and sort by date
    List<UserInputForm> sensorDataList = UserInputForm.fetchSoilSensorData(userId);

    if (sensorDataList.isEmpty()) {
        showError("No sensor data found. Please enter sensor data manually.");
        promptForSensorData();
        return;
    }

    // Sort sensor data by createdAt field in descending order (most recent first)
    DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;
    sensorDataList.sort((data1, data2) -> {
        LocalDateTime date1 = LocalDateTime.parse(data1.getCreatedAt(), formatter);
        LocalDateTime date2 = LocalDateTime.parse(data2.getCreatedAt(), formatter);
        return date2.compareTo(date1);
    });

    // Use the most recent sensor data
    UserInputForm mostRecentData = sensorDataList.get(0);

    // Debugging: Print out the selected recent data
    System.out.println("Using most recent sensor data:");
    System.out.println("Soil Temperature (C): " + mostRecentData.getSoilTemperature());
    System.out.println("Soil Moisture: " + mostRecentData.getSoilMoisture());
    System.out.println("Soil pH: " + mostRecentData.getSoilPH());
    System.out.println("Created At: " + mostRecentData.getCreatedAt());

    // Convert soil temperature from Celsius to Fahrenheit if needed
    double recentSoilTemperatureCelsius = mostRecentData.getSoilTemperature() != null ? mostRecentData.getSoilTemperature() : 0.0;
    double recentSoilTemperatureFahrenheit = convertCelsiusToFahrenheit(recentSoilTemperatureCelsius);

    double recentSoilMoisture = mostRecentData.getSoilMoisture() != null ? mostRecentData.getSoilMoisture() : 0.0;
    double recentSoilPH = mostRecentData.getSoilPH() != null ? mostRecentData.getSoilPH() : 0.0;

    // Call the prediction method using the recent values
    predictPestOrDisease(recentSoilTemperatureFahrenheit, recentSoilMoisture, recentSoilPH);
}

    private double convertCelsiusToFahrenheit(double celsius) {
        return (celsius * 9/5) + 32;
    }
    
    @FXML
    private void backToHome() {
        Navigation.switchScene("primary");
    }

    // Method to predict pest or disease based on user data and soil information
    public void predictPestOrDisease(double soilTemperatureF, double soilMoisture, double soilPH) {
    UserSession userSession = UserSession.getInstance();
    String weatherSummary;
    String weatherAlerts;

    // Fetch weather summary based on coordinates
    if (userSession.getLatitude() != null && userSession.getLongitude() != null) {
        weatherSummary = WeatherForecastController.getWeatherSummary(userSession.getLatitude(), userSession.getLongitude());
    } else {
        weatherSummary = "No coordinates available.";
    }

    // Fetch weather alerts based on coordinates
    if (userSession.getLatitude() != null && userSession.getLongitude() != null) {
        weatherAlerts = WeatherAlertService.fetchWeatherAlerts(userSession.getLatitude(), userSession.getLongitude());
    } else {
        weatherAlerts = "No coordinates available.";
    }

    // Combine soil and weather data for prediction
    StringBuilder predictionResults = new StringBuilder();

    // Warning for high soil temperature (> 77°F) and high soil moisture (> 60%)
    if (soilTemperatureF > 77.0 && soilMoisture > 60.0) {
        predictionResults.append("Warning: Conditions are favorable for root rot due to high soil temperature and moisture.\n");
    }

    if (weatherAlerts.contains("Heavy Rainfall") && soilMoisture > 50.0) {
        predictionResults.append("Warning: Potential risk for fungal diseases due to heavy rainfall and high soil moisture.\n");
    }

    if (soilPH < 5.5) {
        predictionResults.append("Warning: Low soil pH detected, which may lead to increased susceptibility to certain pests and diseases.\n");
    }

    // Warning for high soil temperature (> 86°F) and low soil moisture (< 30%)
    if (soilTemperatureF > 86.0 && soilMoisture < 30.0) {
        predictionResults.append("Warning: High soil temperature and low moisture can increase the risk of spider mites and reduce plant growth.\n");
    }

    // Warning for low soil temperature (< 50°F)
    if (soilTemperatureF < 50.0) {
        predictionResults.append("Warning: Low soil temperature can slow down root growth and cause cold stress in crops.\n");
    }

    // Warning for high soil pH (> 7.5)
    if (soilPH > 7.5) {
        predictionResults.append("Warning: High soil pH detected. Alkaline conditions may reduce nutrient availability and affect plant growth.\n");
    }

    // Warning for acidic soil (low pH < 5.0) and high soil moisture (> 70%)
    if (soilPH < 5.0 && soilMoisture > 70.0) {
        predictionResults.append("Warning: Acidic soil with high moisture can lead to root damage and nutrient deficiencies, favoring pathogens.\n");
    }

    // Warning for heavy rainfall and neutral pH
    if (weatherAlerts.contains("Heavy Rainfall") && soilPH >= 6.0 && soilPH <= 7.0) {
        predictionResults.append("Warning: Heavy rainfall with neutral pH may favor the growth of foliar pathogens such as leaf rust.\n");
    }

    // Warning for prolonged drought conditions
    if (weatherAlerts.contains("Drought") && soilMoisture < 20.0) {
        predictionResults.append("Warning: Prolonged drought and low soil moisture can cause drought stress and increase the risk of pests such as aphids.\n");
    }

    // Warning for high humidity and high soil temperature (> 82.4°F)
    if (soilTemperatureF > 82.4 && soilMoisture > 70.0 && weatherAlerts.contains("High Humidity")) {
        predictionResults.append("Warning: High humidity and temperature may favor powdery mildew or botrytis infection.\n");
    }

    // Warning for cold soil (< 59°F) and high moisture (> 80%)
    if (soilTemperatureF < 59.0 && soilMoisture > 80.0) {
        predictionResults.append("Warning: Cold soil with high moisture increases the risk of root rot caused by Pythium or other fungal pathogens.\n");
    }

    // Warning for soil moisture level too low (< 10%)
    if (soilMoisture < 10.0) {
        predictionResults.append("Warning: Soil moisture is critically low. This can cause wilting, hinder nutrient uptake, and increase plant stress.\n");
    }

    // Warning for soil pH too high (> 8.0) and low nutrient availability
    if (soilPH > 8.0) {
        predictionResults.append("Warning: High soil pH can lead to decreased availability of micronutrients like iron and zinc, leading to deficiencies.\n");
    }

    // Warning for alternating dry and wet conditions
    if (weatherAlerts.contains("Heavy Rainfall") && soilMoisture > 80.0 && soilTemperatureF > 68.0) {
        predictionResults.append("Warning: Alternating dry and wet conditions may increase susceptibility to fungal pathogens, such as Fusarium.\n");
    }

    // Warning for heatwave conditions (> 95°F)
    if (weatherAlerts.contains("Heatwave") && soilTemperatureF > 95.0) {
        predictionResults.append("Warning: Extreme high temperatures detected, which can lead to heat stress in plants and increase pest pressure from insects.\n");
    }

    // Warning for moderate temperature (68-77°F) and high moisture (> 70%)
    if (soilTemperatureF >= 68.0 && soilTemperatureF <= 77.0 && soilMoisture > 70.0) {
        predictionResults.append("Warning: Moderate temperature with high soil moisture is ideal for growth of nematodes and other soil-borne pests.\n");
    }

    // Warning for high pH (> 7.5) and low moisture (< 30%)
    if (soilPH > 7.5 && soilMoisture < 30.0) {
        predictionResults.append("Warning: High pH combined with low moisture can lead to poor nutrient absorption, especially phosphorus and iron.\n");
    }

    // Warning for extended wet conditions (> 85%)
    if (weatherAlerts.contains("Prolonged Rainfall") && soilMoisture > 85.0) {
        predictionResults.append("Warning: Prolonged wet conditions can increase risk of fungal diseases like root rot and downy mildew.\n");
    }

    // Warning for temperature favorable to aphids (59-77°F)
    if (soilTemperatureF > 59.0 && soilTemperatureF < 77.0 && soilMoisture < 50.0) {
        predictionResults.append("Warning: Temperatures between 59°F and 77°F with moderate moisture may promote aphid population growth.\n");
    }

    // Warning for low soil moisture and low soil pH (< 5.5)
    if (soilMoisture < 30.0 && soilPH < 5.5) {
        predictionResults.append("Warning: Low soil moisture combined with low pH can lead to poor plant health and increased susceptibility to pests such as root aphids.\n");
    }

    // Warning for low soil pH (< 5.5) and high soil temperature (> 86°F)
    if (soilPH < 5.5 && soilTemperatureF > 86.0) {
        predictionResults.append("Warning: Low pH and high soil temperature can cause nutrient imbalances, making plants more vulnerable to stress and disease.\n");
    }

    // Warning for high soil moisture due to irrigation
    if (soilMoisture > 80.0 && weatherSummary.contains("Irrigation")) {
        predictionResults.append("Warning: Over-irrigation detected. Excessive moisture can lead to root diseases and nutrient leaching.\n");
    }

    // Warning for frost conditions (< 41°F)
    if (weatherAlerts.contains("Frost") && soilTemperatureF < 41.0) {
        predictionResults.append("Warning: Frost conditions detected. Low soil temperature can damage root systems and hinder plant growth.\n");
    }

    // If no warnings are generated, add a default message
    if (predictionResults.length() == 0) {
        predictionResults.append("No significant pest or disease risks detected under current conditions.");
    }

    // Display prediction results in the pestDiseaseBox
    displayPredictionResults(predictionResults.toString());
}

private void displayPredictionResults(String results) {
        // Clear any existing output from pestDiseaseBox to ensure no old results are displayed
        pestDiseaseBox.getChildren().clear();

        // Split the results into individual warnings based on the newline character
        String[] warnings = results.split("\n");

        // Iterate over each warning and create a label for it
        for (String warning : warnings) {
            if (!warning.trim().isEmpty()) {
                Label warningLabel = new Label(warning);
                warningLabel.setWrapText(true); // Allow text to wrap to the next line if it's too long
                warningLabel.setStyle("-fx-padding: 10; -fx-background-color: #f9f9f9; -fx-border-color: lightgray; -fx-border-radius: 5; -fx-max-width: Infinity;");
                
                // Add the warning label to the VBox
                pestDiseaseBox.getChildren().add(warningLabel);
            }
        }

        // Debugging: Print the result to the console to ensure it's not empty
        System.out.println("Prediction Results: " + results);
    }


// Helper method to show an error message using a dialog
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
    
}