package com.planningandrotation.cropplannerfx.ui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import javafx.application.Platform;
import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.VBox;

public class AlertsController {

    @FXML
    private Label weatherAlertsLabel;

    @FXML
    private VBox cropAlertBox;

    @FXML
    private void initialize() {
        // Fetch and display weather alerts based on user coordinates when the Alerts page is loaded
        Platform.runLater(() -> {
            fetchWeatherAlertsForUser();
            fetchCropAlertsForUser();
        });
    }

    // Method to fetch weather alerts using user's coordinates
    private void fetchWeatherAlertsForUser() {
        UserSession userSession = UserSession.getInstance();

        // Check if user's latitude and longitude are available
        if (userSession.getLatitude() != null && userSession.getLongitude() != null) {
            double latitude = userSession.getLatitude();
            double longitude = userSession.getLongitude();
            getWeatherAlertsForCoordinates(latitude, longitude);
        } else {
            showError("User's location data is not available. Please update your profile with valid coordinates.");
        }
    }

    // Method to fetch weather alerts for a given set of coordinates using WeatherAlertService
    private void getWeatherAlertsForCoordinates(double latitude, double longitude) {
        Platform.runLater(() -> {
            String alerts = WeatherAlertService.fetchWeatherAlerts(latitude, longitude);
            updateWeatherAlertsPanel(alerts);
        });
    }

    // Method to update the alerts label in the Alerts page
    private void updateWeatherAlertsPanel(String alerts) {
        weatherAlertsLabel.setText(alerts);
    }

    // Method to fetch crop alerts for the user
private void fetchCropAlertsForUser() {
    UserSession userSession = UserSession.getInstance();
    int loggedInUserID = userSession.getUserId();

    // Create UserCrops instance to fetch crops
    UserCrops userCrops = new UserCrops(loggedInUserID);
    List<Crop> crops = userCrops.fetchUserCrops();

    // Format current date for comparison
    LocalDate currentDate = LocalDate.now();

    // Clear existing crop alerts
    cropAlertBox.getChildren().clear();

    // Debugging: Print the crops fetched from the database
    System.out.println("Fetched " + crops.size() + " crops for user.");

    // Loop through the crops and find those that need attention
    crops.stream()
        .peek(crop -> {
            // Print details of each crop before filtering to see if they are being filtered out incorrectly
            System.out.println("Processing crop: " + crop.getName() + " (Variety: " + crop.getVariety() + ")");
        })
        .filter(crop -> {
            // Only include crops that are not harvested and have a harvest date
            if (crop.getIsHarvested() == 0 && crop.getHarvestDate() != null) {
                try {
                    // Handle the case where harvest date is only a month (e.g., "June")
                    String harvestDateStr = crop.getHarvestDate();
                    LocalDate harvestDate;

                    if (harvestDateStr.matches("[A-Za-z]+")) {
                        // Parse the month and set the harvest date as the last day of that month
                        Month month = Month.valueOf(harvestDateStr.toUpperCase());
                        harvestDate = LocalDate.of(currentDate.getYear(), month, month.length(currentDate.isLeapYear()));
                    } else {
                        // If the date format is not a simple month, attempt to parse it as a full date
                        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
                        harvestDate = LocalDate.parse(harvestDateStr, formatter);
                    }

                    // Now, we want to compare `created_at` to make sure the crop should have reached this state by now.
                    String createdAtStr = crop.getCreatedAt();
                    if (createdAtStr != null) {
                        LocalDateTime createdAt;

                        // Attempt parsing the `created_at` with multiple formats
                        try {
                            DateTimeFormatter formatter1 = DateTimeFormatter.ofPattern("yyyy-M-d'T'HH:mm:ss.SSSSSSS");
                            createdAt = LocalDateTime.parse(createdAtStr, formatter1);
                        } catch (DateTimeParseException e1) {
                            try {
                                DateTimeFormatter formatter2 = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss.SSSSSSS");
                                createdAt = LocalDateTime.parse(createdAtStr, formatter2);
                            } catch (DateTimeParseException e2) {
                                try {
                                    DateTimeFormatter formatter3 = DateTimeFormatter.ofPattern("yyyy-M-d'T'HH:mm:ss");
                                    createdAt = LocalDateTime.parse(createdAtStr, formatter3);
                                } catch (DateTimeParseException e3) {
                                    System.err.println("Error parsing created_at value for crop: " + crop.getName() + " - Created At: " + createdAtStr);
                                    return false; // Skip this crop if parsing fails for all formats
                                }
                            }
                        }

                        LocalDate creationDate = createdAt.toLocalDate();

                        // Debugging information
                        System.out.println("Parsed created_at value for crop: " + crop.getName() + " (Variety: " + crop.getVariety() + ")");
                        System.out.println("Created at date: " + creationDate);

                        // Add alert if harvest date is today or past and `created_at` is valid
                        if (!harvestDate.isAfter(currentDate) && creationDate.isBefore(currentDate)) {
                            return true;
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Unexpected error while processing crop: " + crop.getName() + " - Error: " + e.getMessage());
                }
            }
            return false;
        })
        .forEach(crop -> {
            // Create a label for each alert
            Label alertLabel = new Label(String.format("Crop '%s' (Variety: %s) is past its harvest date (%s) and needs attention!",
                    crop.getName(), crop.getVariety(), crop.getHarvestDate()));
            alertLabel.setStyle("-fx-text-fill: red; -fx-font-weight: bold;");

            // Add the alert label to the cropAlertBox
            cropAlertBox.getChildren().add(alertLabel);
        });
}
    // Helper method to show an error message using a dialog
    private void showError(String message) {
        Alert alert = new Alert(Alert.AlertType.ERROR);
        alert.setTitle("Error");
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }

    @FXML
    private void backToHome() {
        Navigation.switchScene("primary");
    }
}