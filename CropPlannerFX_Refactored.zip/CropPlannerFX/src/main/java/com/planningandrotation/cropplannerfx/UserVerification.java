/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

/**
 *
 * @author djlan
 */
import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.*;

public class UserVerification {

    public static int verifyUser(String username, String password) {
    try {
        // URL with the query parameters (if supported)
        String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/users/";

        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))  // Use the base URL without appending the username query
                .header("Content-Type", "application/json")  // Set correct content type
                .build();

        // Send GET request
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // Check if status code is 200 (OK) which indicates the user exists
        if (response.statusCode() == 200) {
            System.out.println("User Found!");
            String responseBody = response.body();

            // Parse the JSON response
            JSONObject jsonResponse = new JSONObject(responseBody);
            JSONArray items = jsonResponse.getJSONArray("items");

            // Iterate through the items to find the correct username
            for (int i = 0; i < items.length(); i++) {
                JSONObject user = items.getJSONObject(i);

                // Check if the username matches
                if (user.getString("username").equalsIgnoreCase(username.trim())) {
                    String storedPassword = user.getString("password");

                    // Extract the user_id as an integer
                    int userID = user.getInt("user_id");

                    // Compare the entered password with the stored password
                    if (storedPassword.equals(password.trim())) {
                        // Set user details in UserSession after successful login
                        UserSession userSession = UserSession.getInstance();
                        userSession.setUserId(userID);
                        userSession.setUsername(username);

                        // Extract city, state, latitude, longitude if available
                        if (user.has("city") && !user.isNull("city")) {
                            userSession.setCity(user.getString("city"));
                        }
                        if (user.has("state") && !user.isNull("state")) {
                            userSession.setState(user.getString("state"));
                        }
                        if (user.has("latitude") && !user.isNull("latitude")) {
                            userSession.setLatitude(user.getDouble("latitude"));
                        }
                        if (user.has("longitude") && !user.isNull("longitude")) {
                            userSession.setLongitude(user.getDouble("longitude"));
                        }

                        return userID;  // Valid user and password, return userID
                    } else {
                        // Password did not match
                        System.out.println("Incorrect password for username: " + username);
                        return -1;
                    }
                }
            }

            // Username not found in the list
            System.out.println("Username not found: " + username);
        } else {
            System.out.println("Failed to retrieve users. Response code: " + response.statusCode());
        }

        // Return -1 if user not found or password doesn't match
        return -1;
    } catch (Exception e) {
        e.printStackTrace();
        return -1;
    }
}
}