package com.planningandrotation.cropplannerfx;

import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author djlan
 */
public class Crop {
    // All data fields
    private String name;
    private String variety;
    private String plantingDate;
    private String harvestDate; 
    private String fertilizationDetails;
    private String careNotes;
    private double avgMarketPriceLb; // Replacing avgPrice with avgMarketPriceLb in dollars per lb
    private String avgYield; // Yield in pounds per acre
    private String soilTemp; // Soil temperature requirement
    private String soilMoisture; // Soil moisture requirement
    private String soilPH; // Soil pH requirement
    private String region; // Region suitable for the crop
    private String imagePath;
    private int userCropId;
    private int isDeleted;
    private int isHarvested;
    private String harvestedYield;
    private JSONArray links;
    private double productionCostLb; // Cost in dollars per lb
    private String createdAt;

    // Constructor without userId
    public Crop(String name, String variety, String plantingDate, String harvestDate,
            String fertilizationDetails, String careNotes, double avgMarketPriceLb, String avgYield,
            String soilTemp, String soilMoisture, String soilPH, String region,
            String imagePath, int userCropId, int isDeleted, int isHarvested, String harvestedYield, 
            JSONArray links, double productionCostLb, String createdAt) {
        this.name = name;
        this.variety = variety;
        this.plantingDate = plantingDate;
        this.harvestDate = harvestDate;
        this.fertilizationDetails = fertilizationDetails;
        this.careNotes = careNotes;
        this.avgMarketPriceLb = avgMarketPriceLb;
        this.avgYield = avgYield;
        this.soilTemp = soilTemp;
        this.soilMoisture = soilMoisture;
        this.soilPH = soilPH;
        this.region = region;
        this.imagePath = imagePath;
        this.userCropId = userCropId;
        this.isDeleted = isDeleted;
        this.isHarvested = isHarvested;
        this.harvestedYield = harvestedYield;
        this.links = links;
        this.productionCostLb = productionCostLb;
        this.createdAt = createdAt;
    }

    // Getters for each field
    public String getName() { return name; }
    public String getVariety() { return variety; }
    public String getPlantingDate() { return plantingDate; }
    public String getHarvestDate() { return harvestDate; } 
    public String getFertilizationDetails() { return fertilizationDetails; }
    public String getCareNotes() { return careNotes; }
    public double getAvgMarketPriceLb() { return avgMarketPriceLb; }
    public String getAvgYield() { return avgYield; }
    public String getSoilTemp() { return soilTemp; }
    public String getSoilMoisture() { return soilMoisture; }
    public String getSoilPH() { return soilPH; }
    public String getRegion() { return region; }
    public String getImagePath() { return imagePath; }
    public int getUserCropId() { return userCropId; }
    public int getIsDeleted() { return isDeleted; }
    public int getIsHarvested() { return isHarvested; }
    public String getHarvestedYield() { return harvestedYield; }
    public JSONArray getLinks() { return links; }
    public double getProductionCostLb() { return productionCostLb; }

    public void setHarvestedYield(String harvestedYield) {
        this.harvestedYield = harvestedYield;
    }

    public void setIsHarvested(int isHarvested) {
        this.isHarvested = isHarvested;
    }

    public double getMinSoilTemp() {
        return getMinFromRange(soilTemp);
    }

    public double getMaxSoilTemp() {
        return getMaxFromRange(soilTemp);
    }

    public double getMinMoisture() {
        return getMinFromRange(soilMoisture);
    }

    public double getMaxMoisture() {
        return getMaxFromRange(soilMoisture);
    }

    public double getMinPH() {
        return getMinFromRange(soilPH);
    }

    public double getMaxPH() {
        return getMaxFromRange(soilPH);
    }
    
    public double getMinFromRange(String range) {
        try {
            return Double.parseDouble(range.split("-")[0].trim());
        } catch (Exception e) {
            return Double.NaN; // or some other value to indicate an error
        }
    }

    public double getMaxFromRange(String range) {
        try {
            return Double.parseDouble(range.split("-")[1].trim());
        } catch (Exception e) {
            return Double.NaN; // or some other value to indicate an error
        }
    }
    
    // Getter for createdAt
    public String getCreatedAt() {
        return createdAt;
    }

    // Setter for createdAt if needed
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    // Method to get the link with the specified rel
    public String getLink(String rel) {
        if (links != null) {
            for (int i = 0; i < links.length(); i++) {
                JSONObject linkObj = links.getJSONObject(i);
                if (linkObj.getString("rel").equals(rel)) {
                    return linkObj.getString("href");
                }
            }
        }
        return null; // Return null if no matching link found
    }
}