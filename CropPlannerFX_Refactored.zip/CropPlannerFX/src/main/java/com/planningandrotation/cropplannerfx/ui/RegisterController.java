package com.planningandrotation.cropplannerfx.ui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author djlan
 */
public class RegisterController {

   @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private TextField firstNameField;

    @FXML
    private Button registerButton;
    
    @FXML
    private TextField cityField;

    @FXML
    private TextField stateField;

    @FXML
    private void initialize() {
        // Add action to the register button
        //registerButton.setOnAction(event -> handleRegister());
    }

    @FXML
private void handleRegister() {
    String username = usernameField.getText();
    String password = passwordField.getText();
    String firstName = firstNameField.getText();
    String city = cityField.getText();
    String state = stateField.getText();

    // Check for empty fields 
    if (username.isEmpty() || password.isEmpty() || firstName.isEmpty() || city.isEmpty() || state.isEmpty()) {
        showAlert(AlertType.WARNING, "Form Incomplete", "Please fill in all fields.");
        return;
    }

    try {
        // Call the register user method
        boolean success = UserRegistration.registerUser(username, password, firstName, city, state);
        if (success) {
            showAlert(AlertType.INFORMATION, "Success", "User registered successfully!");
            clearFields();
        } else {
            showAlert(AlertType.ERROR, "Registration Failed", "Failed to register user. Please try again.");
        }
    } catch (UserRegistration.UsernameTakenException e) {
        // Handle the specific case when the username is already taken
        showAlert(AlertType.ERROR, "Username Taken", "The username is already taken. Please choose a different one.");
    }
}

    private void clearFields() {
        // Clear input fields after successful registration
        usernameField.clear();
        passwordField.clear();
        firstNameField.clear();
        cityField.clear();
        stateField.clear();
    }

    private void showAlert(AlertType alertType, String title, String content) {
        // Helper method to display alert messages
        Alert alert = new Alert(alertType);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(content);
        alert.showAndWait();
    }  
    
    @FXML
    private void backToSignIn() {
        Navigation.switchScene("signIn");
    }
}