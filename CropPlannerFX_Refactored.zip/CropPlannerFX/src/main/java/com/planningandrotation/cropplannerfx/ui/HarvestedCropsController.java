package com.planningandrotation.cropplannerfx.ui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import org.json.JSONObject;
import java.net.http.HttpClient;
import java.util.List;
import java.util.Optional;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;

/**
 * FXML Controller class
 *
 * @author djlan
 */

public class HarvestedCropsController implements Initializable {

    @FXML
    private VBox harvestedCropsBox;

    @FXML
    private Button backButton;

    private final UserCrops userCrops;

    public HarvestedCropsController() {
        // Assuming loggedInUserID is available globally
        int loggedInUserID = UserSession.getInstance().getUserId();
        userCrops = new UserCrops(loggedInUserID);
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        populateHarvestedCrops();
    }

    @FXML
    private void backToHome() {
        Navigation.switchScene("primary");
    }

    private void populateHarvestedCrops() {
        harvestedCropsBox.getChildren().clear(); // Clear any existing nodes

        // Fetch crops for the logged-in user, ensuring it is always a fresh list
        List<Crop> harvestedCrops = userCrops.fetchUserCrops();

        harvestedCrops.stream()
                .filter(crop -> {
                    System.out.println("Filtering crop: " + crop.getName() + ", is_harvested: " + crop.getIsHarvested() + ", is_deleted: " + crop.getIsDeleted());
                    return crop.getIsDeleted() == 0 && crop.getIsHarvested() == 1; // Only include crops that are not deleted and are harvested
                })
                .forEach(crop -> {
                    System.out.println("Including harvested crop: " + crop.getName()); // Debugging statement

                    // Create an HBox to hold the harvested crop details
                    HBox harvestedCropHBox = new HBox(15);
                    harvestedCropHBox.setPadding(new Insets(10));
                    harvestedCropHBox.setAlignment(Pos.CENTER_LEFT);
                    harvestedCropHBox.setStyle("-fx-border-color: lightgrey; -fx-border-width: 1; -fx-border-radius: 5; -fx-background-color: #F9F9F9;");
                    harvestedCropHBox.setMaxWidth(Double.MAX_VALUE); // Allow the HBox to take the full width
                    harvestedCropHBox.setPrefWidth(harvestedCropsBox.getWidth()); // Set preferred width to match the parent box width

                    // Ensure HBox expands properly
                    HBox.setHgrow(harvestedCropHBox, Priority.ALWAYS);

                    // Create a VBox for the harvested crop details
                    VBox harvestedCropDetailsBox = new VBox(5);
                    harvestedCropDetailsBox.setAlignment(Pos.CENTER_LEFT);
                    harvestedCropDetailsBox.setMaxWidth(Double.MAX_VALUE); // Allow the VBox to take the full width
                    harvestedCropDetailsBox.setPrefWidth(600); // Provide enough space for content

                    // Create labels for each piece of crop information
                    Label harvestedCropLabel = new Label(
                            String.format("Name: %s\nVariety: %s\nPlanting Date: %s\nHarvest Date: %s\nHarvested Amount: %s",
                                    crop.getName(), crop.getVariety(), crop.getPlantingDate(), crop.getHarvestDate(), crop.getHarvestedYield()
                            )
                    );

                    // Set minimum height to ensure all lines are visible
                    harvestedCropLabel.setMinHeight(120); // Adjust this value as needed to fit all lines
                    harvestedCropLabel.setWrapText(true);
                    harvestedCropLabel.setMaxWidth(600); // Set a reasonable maximum width
                    harvestedCropLabel.setPrefWidth(600); // Make sure it takes a reasonable width to display the content

                    // Add the harvested crop label to the details box
                    harvestedCropDetailsBox.getChildren().add(harvestedCropLabel);

                    // Add crop details to the HBox
                    harvestedCropHBox.getChildren().add(harvestedCropDetailsBox);
                    harvestedCropsBox.getChildren().add(harvestedCropHBox); // Add each HBox to the main container
                });
    }
}
