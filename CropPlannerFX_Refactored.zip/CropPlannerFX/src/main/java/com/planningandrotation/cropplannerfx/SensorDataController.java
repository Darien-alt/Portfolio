/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import org.json.JSONObject;
import java.net.http.HttpClient;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Optional;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;

/**
 * FXML Controller class
 *
 * @author djlan
 */

public class SensorDataController implements Initializable {

    @FXML
    private VBox sensorDataBox;

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {
        int userId = UserSession.getInstance().getUserId();
        displaySoilSensorData(userId);
    }
    
    @FXML
    private void backToHome() {
        Navigation.switchScene("primary");
    }

    // Method to populate the sensor data page with user-specific soil data
    private void displaySoilSensorData(int userId) {
    // Fetch soil sensor data for the given user
    List<UserInputForm> sensorDataList = UserInputForm.fetchSoilSensorData(userId);

    // Sort the data by createdAt field in descending order (most recent first)
    DateTimeFormatter formatter = DateTimeFormatter.ISO_LOCAL_DATE_TIME;

    sensorDataList.sort((data1, data2) -> {
    LocalDateTime date1 = LocalDateTime.parse(data1.getCreatedAt(), formatter);
    LocalDateTime date2 = LocalDateTime.parse(data2.getCreatedAt(), formatter);
    return date2.compareTo(date1); // Descending order
});

    // Clear any existing children from sensorDataBox to avoid duplicates
    sensorDataBox.getChildren().clear();

    // Iterate over the fetched data and add it to the VBox
    for (UserInputForm userInput : sensorDataList) {
        String soilDataString = String.format("%s - Soil Moisture: %.2f - Soil Temp: %.2f - Soil PH: %.2f",
                userInput.getCreatedAt().substring(0, 10),  // Only get the date part
                userInput.getSoilMoisture() != null ? userInput.getSoilMoisture() : 0.0,
                userInput.getSoilTemperature() != null ? userInput.getSoilTemperature() : 0.0,
                userInput.getSoilPH() != null ? userInput.getSoilPH() : 0.0);

        Label soilDataLabel = new Label(soilDataString);
        soilDataLabel.setStyle("-fx-padding: 10; -fx-background-color: #f4f4f4; -fx-border-color: lightgray; -fx-border-radius: 5;");
        sensorDataBox.getChildren().add(soilDataLabel);
    }
}
}

