package com.planningandrotation.cropplannerfx;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

import java.io.IOException;
import javafx.scene.image.Image;

/**
 * JavaFX App
 */
public class App extends Application {

    private static Scene scene;

    @Override
    public void start(Stage stage) {
        try {
        // Set the window icon
        stage.getIcons().add(new Image(getClass().getResource("/com/planningandrotation/cropplannerfx/images/icon.png").toExternalForm()));
    } catch (NullPointerException e) {
        System.err.println("Error: Icon image not found.");
        e.printStackTrace();
    }

    // Load the initial FXML for the scene
    try {
        Parent root = loadFXML("signIn.fxml");
        scene = new Scene(root);
        stage.setScene(scene);
    } catch (IOException e) {
        System.err.println("Error loading initial FXML file.");
        e.printStackTrace();
        return; // Exit if the initial scene cannot be loaded
    }

    // Set up navigation
    Navigation.setMainStage(stage);
    Navigation.switchScene("signIn");

    // Show the stage
    stage.setTitle("Crop Planner FX");
    stage.show();
}

    static void setRoot(String fxml) throws IOException {
        scene.setRoot(loadFXML(fxml));
    }

    private static Parent loadFXML(String fxml) throws IOException {
    FXMLLoader fxmlLoader = new FXMLLoader(App.class.getResource("/com/planningandrotation/cropplannerfx/" + fxml));
    return fxmlLoader.load();
    }

    public static void main(String[] args) {
        launch();
    }
    
    public interface HasMainStage {
        void setMainStage(Stage stage);
    }

}