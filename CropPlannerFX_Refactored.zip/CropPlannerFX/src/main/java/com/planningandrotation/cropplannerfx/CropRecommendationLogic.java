/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

/**
 *
 * @author djlan
 */
import javafx.fxml.FXMLLoader;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.layout.VBox;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;
import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javafx.fxml.FXML;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;

public class CropRecommendationLogic {

    private VBox recommendationsBox;
    private Stage mainStage;

    // Constructor to take VBox and Stage
    public CropRecommendationLogic(VBox recommendationsBox, Stage mainStage) {
        this.recommendationsBox = recommendationsBox;
        this.mainStage = mainStage;
    }

    // Method to populate crop recommendations into the VBox
    public void populateRecommendations(List<Crop> recommendations, UserInputForm userInputForm) {
    // Clear existing recommendations, if any
    recommendationsBox.getChildren().clear();

    if (recommendations.isEmpty()) {
        // If no recommendations, show an alert
        Alert alert = new Alert(AlertType.INFORMATION);
        alert.setTitle("No Crop Recommendations");
        alert.setHeaderText(null);
        alert.setContentText("No crops can be recommended based on the provided conditions.");
        alert.showAndWait();
        return;
    }

    for (Crop crop : recommendations) {
        Button button = new Button(crop.getName() + " - " + crop.getVariety());
        button.setStyle("-fx-background-color: #93C57D; -fx-text-fill: black; -fx-font-size: 14px; -fx-font-weight: bold;");

        button.setOnAction(event -> {
            System.out.println("Selected: " + crop.getName() + " - " + crop.getVariety());
            try {
                // Fetch the full crop data using REST API by passing both name and variety
                Crop fullCropDetails = getCropData(crop.getName(), crop.getVariety());

                if (fullCropDetails != null) {
                    // Load the Crop Details page and set the data
                    FXMLLoader loader = new FXMLLoader(getClass().getResource("cropDetails.fxml"));
                    Parent cropDetailsRoot = loader.load();

                    // Get the controller and set the crop data
                    CropDetailsController controller = loader.getController();
                    controller.setCropDetails(fullCropDetails);

                    // Pass the userInputForm to be used in navigation back
                    controller.setUserInputForm(userInputForm);
                    controller.setMainStage(mainStage); // Set the main stage for navigation back

                    // Switch to the new scene (crop details)
                    Scene scene = new Scene(cropDetailsRoot);
                    mainStage.setScene(scene);
                    mainStage.show();
                } else {
                    System.out.println("Crop data could not be fetched.");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        });

        recommendationsBox.getChildren().add(button);
    }
}
    
    private CropRecommendationsController controller;

    public void setController(CropRecommendationsController controller) {
        this.controller = controller;
    }

    // Method to fetch crop data by name using REST API
public Crop getCropData(String cropName, String cropVariety) {
    try {
        String baseUrl = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/crop/?name=" + URLEncoder.encode(cropName, "UTF-8") + "&variety=" + URLEncoder.encode(cropVariety, "UTF-8");
        String url = baseUrl;

        HttpClient client = HttpClient.newHttpClient();
        boolean hasMore = true;

        while (url != null && hasMore) {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                String responseBody = response.body();
                System.out.println("Fetched crop data for: " + cropName + " - " + cropVariety);
                System.out.println("Response body: " + responseBody);

                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONArray items = jsonResponse.getJSONArray("items");

                for (int i = 0; i < items.length(); i++) {
                    JSONObject cropJson = items.getJSONObject(i);

                    if (cropJson.has("name") && cropJson.has("variety") &&
                            cropJson.getString("name").equalsIgnoreCase(cropName) &&
                            cropJson.getString("variety").equalsIgnoreCase(cropVariety)) {

                        String name = cropJson.optString("name", "Unknown");
                        String variety = cropJson.optString("variety", "Unknown");
                        String plantingDate = cropJson.optString("planting_date", "Unknown");
                        String harvestDate = cropJson.optString("harvest_date", "Unknown");
                        String fertilizationDetails = cropJson.optString("fertilization_details", "Unknown");
                        String careNotes = cropJson.optString("care_notes", "Unknown");
                        double avgMarketPriceLb = cropJson.optDouble("avg_market_price_lb", 0.0);
                        String avgYield = cropJson.optString("avg_yield", "Unknown"); // Fetch as string
                        String soilTemp = cropJson.optString("soil_temp", "Unknown");
                        String soilMoisture = cropJson.optString("soil_moisture", "Unknown");
                        String soilPH = cropJson.optString("soil_ph", "Unknown");
                        String region = cropJson.optString("region", "Unknown");
                        String imagePath = cropJson.optString("image_path", null);
                        int userCropId = cropJson.optInt("user_crop_id", 0);
                        int isDeleted = cropJson.optInt("is_deleted", 0);
                        int isHarvested = cropJson.optInt("is_harvested", 0);
                        String harvestedYield = cropJson.optString("harvested_yield", "Unknown");
                        JSONArray links = cropJson.optJSONArray("links");
                        double productionCostLb = cropJson.optDouble("production_cost_lb", 0.0);
                        String createdAt = cropJson.optString("created_at", null);

                        return new Crop(
                                name,
                                variety,
                                plantingDate,
                                harvestDate,
                                fertilizationDetails,
                                careNotes,
                                avgMarketPriceLb,
                                avgYield,  // Use the avgYield string
                                soilTemp,
                                soilMoisture,
                                soilPH,
                                region,
                                imagePath,
                                userCropId,
                                isDeleted,
                                isHarvested,
                                harvestedYield,
                                links,
                                productionCostLb,
                                createdAt
                        );
                    }
                }

                hasMore = jsonResponse.has("hasMore") && jsonResponse.getBoolean("hasMore");
                url = null;

                if (hasMore) {
                    JSONArray links = jsonResponse.getJSONArray("links");
                    for (int i = 0; i < links.length(); i++) {
                        JSONObject link = links.getJSONObject(i);
                        if (link.getString("rel").equals("next")) {
                            url = link.getString("href");
                            break;
                        }
                    }
                }
            } else {
                System.out.println("Failed to fetch crop data. Response code: " + response.statusCode());
                return null;
            }
        }

        System.out.println("Crop not found for: " + cropName + " - " + cropVariety);
        return null;

    } catch (Exception e) {
        e.printStackTrace();
        return null;
    }
}

public List<Crop> fetchAllCrops() {
    List<Crop> allCrops = new ArrayList<>();

    try {
        String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/crop/";
        HttpClient client = HttpClient.newHttpClient();
        boolean hasMore = true;

        while (url != null && hasMore) {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                String responseBody = response.body();
                System.out.println("Fetched all crops successfully.");
                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONArray items = jsonResponse.getJSONArray("items");

                for (int i = 0; i < items.length(); i++) {
                    JSONObject cropJson = items.getJSONObject(i);

                    String name = cropJson.optString("name", "Unknown");
                    String variety = cropJson.optString("variety", "Unknown");
                    String plantingDate = cropJson.optString("planting_date", "Unknown");
                    String harvestDate = cropJson.optString("harvest_date", "Unknown");
                    String fertilizationDetails = cropJson.optString("fertilization_details", "Unknown");
                    String careNotes = cropJson.optString("care_notes", "Unknown");
                    double avgMarketPriceLb = Double.parseDouble(cropJson.optString("avg_market_price_lb", "0").replaceAll("[^0-9.]", ""));
                    double productionCostLb = cropJson.optDouble("production_cost_lb", 0.0);

                    String avgYield = cropJson.optString("avg_yield", "Unknown");

                    String soilTemp = cropJson.optString("optimal_soil_temp", "Unknown");
                    String soilMoisture = cropJson.optString("optimal_moisture", "Unknown");
                    String soilPH = cropJson.optString("optimal_ph", "Unknown");
                    String region = cropJson.optString("region", "Unknown");
                    String imagePath = cropJson.optString("image_path", null);
                    int userCropId = cropJson.optInt("user_crop_id", 0);
                    int isDeleted = cropJson.optInt("is_deleted", 0);
                    int isHarvested = cropJson.optInt("is_harvested", 0);
                    String harvestedYield = cropJson.optString("harvested_yield", null);
                    JSONArray links = cropJson.optJSONArray("links");
                    String createdAt = cropJson.optString("created_at", null);

                    // Create Crop object and add to the list
                    Crop crop = new Crop(name, variety, plantingDate, harvestDate, fertilizationDetails, careNotes,
                            avgMarketPriceLb, avgYield, soilTemp, soilMoisture, soilPH, region, imagePath, userCropId,
                            isDeleted, isHarvested, harvestedYield, links, productionCostLb, createdAt);
                    allCrops.add(crop);
                }

                // Check if there are more pages to fetch
                hasMore = jsonResponse.has("hasMore") && jsonResponse.getBoolean("hasMore");
                url = null;

                // Update the URL if more data is available
                if (hasMore) {
                    JSONArray links = jsonResponse.getJSONArray("links");
                    for (int i = 0; i < links.length(); i++) {
                        JSONObject link = links.getJSONObject(i);
                        if (link.getString("rel").equals("next")) {
                            url = link.getString("href");
                            break;
                        }
                    }
                }
            } else {
                System.out.println("Failed to fetch crop data. Response code: " + response.statusCode());
                hasMore = false; // Stop fetching if the response is unsuccessful
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return allCrops;
}
    
public double[] parseRange(String range) {
    if (range == null || range.isEmpty() || range.equalsIgnoreCase("Unknown")) {
        System.err.println("Error parsing range: " + range);
        return null; // Indicate an error occurred
    }
    if (range.equalsIgnoreCase("Flooded")) {
        // Handle special case for flooded
        System.out.println("Moisture is flooded, setting range accordingly.");
        return new double[] { Double.MIN_VALUE, Double.MAX_VALUE }; // Or some other logic that suits your app
    }
    try {
        String[] parts = range.split("-");
        if (parts.length != 2) {
            System.err.println("Unexpected range format: " + range);
            return null;
        }
        double min = Double.parseDouble(parts[0].trim());
        double max = Double.parseDouble(parts[1].trim());
        return new double[] { min, max };
    } catch (Exception e) {
        System.err.println("Error parsing range: " + range);
        return null; // Indicate an error occurred
    }
}

    // main Crop Recommend Logic
public List<Crop> recommendCrops(UserInputForm userInputForm) {
    double currentSoilTemp = userInputForm.getSoilTemperature();
    double currentMoisture = userInputForm.getSoilMoisture();
    double currentPH = userInputForm.getSoilPH();
    String userRegion = userInputForm.getRegion();
    String userState = userInputForm.getState(); // Assuming UserInputForm has a getState() method

    List<Crop> allCrops = fetchAllCrops(); // Replace with a method that gets all crop data, including environmental/economic information
    List<Crop> recommendedCrops = new ArrayList<>();

    // Define crops commonly grown in Michigan (using the crop list you provided)
    Set<String> michiganCrops = new HashSet<>(Arrays.asList(
            "Corn", "Wheat", "Soybeans", "Oats", "Barley", "Potatoes",
            "Cabbage", "Tomatoes", "Carrots", "Sugar Beets", "Garlic", "Chilli Peppers", "Sunflower", "Canola"
    ));

    for (Crop crop : allCrops) {
        boolean isSuitable = true;

        System.out.println("Checking crop: " + crop.getName());

        // Check if the crop is commonly grown in Michigan (if the state is "MI")
        if ("MI".equalsIgnoreCase(userState) && !michiganCrops.contains(crop.getName())) {
            System.out.println("Cultural check failed for crop: " + crop.getName() + " - Not commonly grown in Michigan.");
            isSuitable = false;
        }

        // Soil temperature check
        double[] soilTempRange = parseRange(crop.getSoilTemp());
        if (soilTempRange != null) {
            if (currentSoilTemp < soilTempRange[0] || currentSoilTemp > soilTempRange[1]) {
                System.out.println("Temperature check failed for crop: " + crop.getName());
                isSuitable = false;
            }
        }

        // Soil moisture check
        double[] moistureRange = parseRange(crop.getSoilMoisture());
        if (moistureRange != null) {
            if (crop.getSoilMoisture().equalsIgnoreCase("Flooded") && currentMoisture < 95) {   // threshold for flooded
                System.out.println("Moisture requirement is flooded for crop: " + crop.getName());
                isSuitable = false;
            } else if (currentMoisture < moistureRange[0] || currentMoisture > moistureRange[1]) {
                System.out.println("Moisture check failed for crop: " + crop.getName());
                isSuitable = false;
            }
        }

        // Soil pH check
        double[] phRange = parseRange(crop.getSoilPH());
        if (phRange != null) {
            if (currentPH < phRange[0] || currentPH > phRange[1]) {
                System.out.println("PH check failed for crop: " + crop.getName());
                isSuitable = false;
            }
        }

        // Region check
        if (!crop.getRegion().equalsIgnoreCase(userRegion)) {
            System.out.println("Region check failed for crop: " + crop.getName());
            isSuitable = false;
        }

        // Profitability check
        System.out.println("Checking profitability for crop: " + crop.getName());
        System.out.println("Average Market Price per lb: " + crop.getAvgMarketPriceLb());
        System.out.println("Production Cost per lb: " + crop.getProductionCostLb());
        System.out.println("Average Yield: " + crop.getAvgYield());

        double avgYieldValue = 0.0;
        try {
            if (!crop.getAvgYield().equalsIgnoreCase("Unknown")) {
                avgYieldValue = Double.parseDouble(crop.getAvgYield().replaceAll("[^0-9.]", ""));
            }
        } catch (NumberFormatException e) {
            System.err.println("Failed to parse avgYield: " + crop.getAvgYield());
        }

        double profitPotential = (crop.getAvgMarketPriceLb() - crop.getProductionCostLb()) * avgYieldValue;
        System.out.println("Calculated Profit Potential: " + profitPotential);
        System.out.println("Min Profit Threshold: " + userInputForm.getMinProfitThreshold());
        if (profitPotential < userInputForm.getMinProfitThreshold()) {
            System.out.println("Profitability check failed for crop: " + crop.getName() +
                    " - Profit Potential: " + profitPotential +
                    ", Min Profit Threshold: " + userInputForm.getMinProfitThreshold());
            isSuitable = false;
        } else {
            System.out.println("Profitability check passed for crop: " + crop.getName() +
                    " - Profit Potential: " + profitPotential);
        }

        // Add crop to recommended list if all checks are passed
        if (isSuitable) {
            System.out.println("Crop added: " + crop.getName());
            recommendedCrops.add(crop);
        }
    }

    return recommendedCrops;
}
    

}