/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TextField;

/**
 * FXML Controller class
 *
 * @author djlan
 */
public class AddCropLocationController implements Initializable {

    /**
     * Initializes the controller class.
     */
    
    @FXML
    private ComboBox<String> stateBox;
    @FXML
    private TextField cityField;
    @FXML
    private TextField acreField;

    private UserInputForm userInputForm;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
       // Populate the ComboBox with state names and abbreviations
        stateBox.setItems(FXCollections.observableArrayList(
                "Alabama (AL)", "Alaska (AK)", "Arizona (AZ)", "Arkansas (AR)",
                "California (CA)", "Colorado (CO)", "Connecticut (CT)", "Delaware (DE)",
                "Florida (FL)", "Georgia (GA)", "Hawaii (HI)", "Idaho (ID)",
                "Illinois (IL)", "Indiana (IN)", "Iowa (IA)", "Kansas (KS)",
                "Kentucky (KY)", "Louisiana (LA)", "Maine (ME)", "Maryland (MD)",
                "Massachusetts (MA)", "Michigan (MI)", "Minnesota (MN)", "Mississippi (MS)",
                "Missouri (MO)", "Montana (MT)", "Nebraska (NE)", "Nevada (NV)",
                "New Hampshire (NH)", "New Jersey (NJ)", "New Mexico (NM)", "New York (NY)",
                "North Carolina (NC)", "North Dakota (ND)", "Ohio (OH)", "Oklahoma (OK)",
                "Oregon (OR)", "Pennsylvania (PA)", "Rhode Island (RI)", "South Carolina (SC)",
                "South Dakota (SD)", "Tennessee (TN)", "Texas (TX)", "Utah (UT)",
                "Vermont (VT)", "Virginia (VA)", "Washington (WA)", "West Virginia (WV)",
                "Wisconsin (WI)", "Wyoming (WY)"
        ));
    }    
    
    public void backToMain(){
        Navigation.switchScene("primary");
    }
    
    private void showError(String message) {
    Alert alert = new Alert(Alert.AlertType.ERROR);
    alert.setTitle("Validation Error");
    alert.setHeaderText(null);
    alert.setContentText(message);
    alert.showAndWait();
}
    
     @FXML
    private void toAddCropSensor() {
        // Validate the state field
        String state = stateBox.getSelectionModel().getSelectedItem();
        if (state == null || state.trim().isEmpty()) {
            showError("Please select a valid state.");
            return;
        }

        String stateAbbreviation = state.substring(state.length() - 3, state.length() - 1);

        // Validate the city field
        String city = cityField.getText().trim();
        if (city.isEmpty()) {
            showError("Please enter a valid city.");
            return;
        }

        // Validate the acreage field
        String acreageText = acreField.getText().trim();
        double acreage = 0;
        try {
            acreage = Double.parseDouble(acreageText);
            if (acreage <= 0) {
                throw new NumberFormatException("Acreage must be positive.");
            }
        } catch (NumberFormatException e) {
            showError("Please enter a valid, positive acreage.");
            return;
        }

        userInputForm = new UserInputForm(UserSession.getInstance().getUserId(), stateAbbreviation, city, acreage);

        // Pass the userInputForm to the next scene's controller and clear the fields
        Navigation.switchScene("addCropSensor", controller -> {
            AddCropSensorController sensorController = (AddCropSensorController) controller;
            sensorController.setUserInputForm(userInputForm);
            sensorController.resetFields();  // Clear the fields in Sensor page when navigating forward
        });
    }
    
    public void resetFields() {
    stateBox.getSelectionModel().clearSelection();
    cityField.clear();
    acreField.clear();
}
    
public void populateLocationFromUserAccount() {
    UserSession userSession = UserSession.getInstance();
    
    // Fetch state and city from user's session
    String userState = userSession.getState();
    String userCity = userSession.getCity();
    
    if (userState != null && userCity != null) {
        // Iterate through stateBox items to find the matching state name
        for (String stateOption : stateBox.getItems()) {
            if (stateOption.toLowerCase().startsWith(userState.toLowerCase())) {
                stateBox.getSelectionModel().select(stateOption);
                break;
            }
        }
        
        // Set the city field
        cityField.setText(userCity);
    }
}
}
