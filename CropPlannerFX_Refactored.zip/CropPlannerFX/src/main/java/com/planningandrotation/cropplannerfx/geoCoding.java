/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import org.json.JSONObject;

/**
 *
 * @author djlan
 */
public class geoCoding {
    
    private static final String API_KEY = "52b55545d8db45c7a04db9a589149cec";

    
     public static double[] getCoordinates(String city, String state) {
        try {
            // Construct the request URL using the city and state
            String urlString = String.format(
                "https://api.geoapify.com/v1/geocode/search?text=%s%%2C%%20%s%%2C%%20United%%20States&apiKey=%s",
                city, state, API_KEY
            );
            URL url = new URL(urlString);

            // Create the HTTP connection and set headers
            HttpURLConnection http = (HttpURLConnection) url.openConnection();
            http.setRequestProperty("Accept", "application/json");

            // Check response code
            int responseCode = http.getResponseCode();
            if (responseCode != 200) {
                System.out.println("Error: " + responseCode + " " + http.getResponseMessage());
                return null;
            }

            // Read the response from input stream
            BufferedReader reader = new BufferedReader(new InputStreamReader(http.getInputStream()));
            StringBuilder responseBuilder = new StringBuilder();
            String line;
            while ((line = reader.readLine()) != null) {
                responseBuilder.append(line);
            }
            reader.close();

            // Parse JSON response
            JSONObject responseJson = new JSONObject(responseBuilder.toString());
            if (responseJson.has("features")) {
                JSONObject location = responseJson.getJSONArray("features")
                                                  .getJSONObject(0)
                                                  .getJSONObject("properties");
                double latitude = location.getDouble("lat");
                double longitude = location.getDouble("lon");

                return new double[]{latitude, longitude};
            } else {
                System.out.println("Location not found.");
            }

            http.disconnect();

        } catch (Exception e) {
            e.printStackTrace();
        }

        return null;
    }
}
