package com.planningandrotation.cropplannerfx.ui;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */

import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.control.TextInputDialog;
import javafx.application.Platform;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import javafx.scene.control.Alert;
import org.json.JSONObject;

/**
 * FXML Controller class
 *
 * @author djlan
 */
public class WeatherForecastController {
    
    @FXML
    private Label weatherLabel;

    @FXML
    private Label tempLabel;

    @FXML
    private Label humidityLabel;

    private static final String API_KEY = "5a7aca5509a8fc06d33175d0f26d77c2";
    
    @FXML
    private void initialize() {
        // Use coordinates from UserSession to get the weather
        Platform.runLater(this::getWeatherForUserLocation);
    }

    // Method to get weather information based on user location from UserSession
    private void getWeatherForUserLocation() {
        UserSession userSession = UserSession.getInstance();

        // Check if coordinates are available in UserSession
        if (userSession.getLatitude() != null && userSession.getLongitude() != null) {
            double latitude = userSession.getLatitude();
            double longitude = userSession.getLongitude();

            // Use the existing method to fetch weather based on coordinates
            String weatherData = getWeatherForLocation(latitude, longitude);

            // Handle the weather response
            if (weatherData != null) {
                handleWeatherResponse(weatherData);
            } else {
                showError("Failed to retrieve weather data. Please try again.");
            }
        } else {
            showError("User's location data is not available. Please update your profile with valid coordinates.");
        }
    }

    // Method to get weather information for a given latitude and longitude
    public static String getWeatherForLocation(double latitude, double longitude) {
        try {
            // API URL using coordinates
            String url = String.format("https://api.openweathermap.org/data/2.5/weather?lat=%f&lon=%f&appid=%s&units=metric", latitude, longitude, API_KEY);

            // Create HTTP client and request
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            // Send the request and get the response synchronously
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Check if response is successful
            if (response.statusCode() == 200) {
                return response.body();  // Return the weather data as a JSON string
            } else {
                System.out.println("Failed to retrieve weather data. Status Code: " + response.statusCode());
                return null;
            }

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // Method to handle the weather response
    private void handleWeatherResponse(String response) {
        try {
            // Parse the response JSON
            JSONObject jsonResponse = new JSONObject(response);

            // Check if response contains valid data
            if (jsonResponse.has("weather")) {
                String weatherDescription = jsonResponse.getJSONArray("weather").getJSONObject(0).getString("description");
                double temperatureCelsius = jsonResponse.getJSONObject("main").getDouble("temp");
                int humidity = jsonResponse.getJSONObject("main").getInt("humidity");

                // Convert Celsius to Fahrenheit
                double temperatureFahrenheit = (temperatureCelsius * 9 / 5) + 32;

                // Update labels with weather data
                updateWeatherForecastPanel(weatherDescription, temperatureCelsius, temperatureFahrenheit, humidity);
            } else if (jsonResponse.has("cod") && jsonResponse.getInt("cod") == 404) {
                showError("Location not found. Please check the coordinates.");
            } else {
                showError("Failed to retrieve weather data. Please try again.");
            }
        } catch (Exception e) {
            e.printStackTrace();
            showError("An error occurred while processing the weather data.");
        }
    }

    // Method to update weather forecast labels
    private void updateWeatherForecastPanel(String weatherDescription, double temperatureCelsius, double temperatureFahrenheit, int humidity) {
        tempLabel.setText(String.format("%.1f °C / %.1f °F", temperatureCelsius, temperatureFahrenheit));
        weatherLabel.setText(weatherDescription);
        humidityLabel.setText(humidity + " %");
    }

    // Helper method to show an error alert
    private void showError(String message) {
        Platform.runLater(() -> {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error");
            alert.setHeaderText(null);
            alert.setContentText(message);
            alert.showAndWait();
        });
    }

    @FXML
    private void backToHome() {
        Navigation.switchScene("primary");
    }

    // Method to get a weather summary for given coordinates
    public static String getWeatherSummary(double latitude, double longitude) {
        try {
            // API URL using latitude and longitude
            String url = String.format("https://api.openweathermap.org/data/2.5/weather?lat=%f&lon=%f&appid=%s&units=metric", latitude, longitude, API_KEY);

            // Create HTTP client and request
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            // Send the request and get the response synchronously
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Check if response is successful
            if (response.statusCode() == 200) {
                // Parse the response JSON
                JSONObject jsonResponse = new JSONObject(response.body());

                // Extract the relevant weather data
                String weatherDescription = jsonResponse.getJSONArray("weather").getJSONObject(0).getString("description");
                double temperatureCelsius = jsonResponse.getJSONObject("main").getDouble("temp");
                int humidity = jsonResponse.getJSONObject("main").getInt("humidity");

                // Return the summary in a readable format
                return String.format("Weather: %s, Temperature: %.1f°C, Humidity: %d%%", weatherDescription, temperatureCelsius, humidity);
            } else if (response.statusCode() == 404) {
                return "Location not found. Please check the coordinates.";
            } else {
                return "Failed to retrieve weather data. Status code: " + response.statusCode();
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "An error occurred while fetching the weather summary.";
        }
    }
}
