/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import org.json.JSONArray;
import org.json.JSONObject;

/**
 *
 * @author djlan
 */
public class UserRegistration {

public static boolean registerUser(String username, String password, String firstName, String city, String state) throws UsernameTakenException {
    try {
        // Check if the username is already taken
        if (isUsernameTaken(username)) {
            throw new UsernameTakenException("Username is already taken. Please choose a different username.");
        }

        // Use geoCoding class to get coordinates from city and state
        double[] coordinates = geoCoding.getCoordinates(city, state);
        if (coordinates == null) {
            System.out.println("Failed to retrieve coordinates. Registration aborted.");
            return false;
        }
        double latitude = coordinates[0];
        double longitude = coordinates[1];

        // URL of the REST endpoint for registering a new user
        String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/users/";

        // Create a JSON object with the user's data
        JSONObject userJson = new JSONObject();
        userJson.put("username", username);
        userJson.put("password", password);
        userJson.put("first_name", firstName);
        userJson.put("city", city);
        userJson.put("state", state);
        userJson.put("latitude", latitude);
        userJson.put("longitude", longitude);

        // Create an HTTP client and request
        HttpClient client = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))  // The REST endpoint for user registration
                .header("Content-Type", "application/json")  // Specify JSON format
                .POST(HttpRequest.BodyPublishers.ofString(userJson.toString()))  // Send user data in the body
                .build();

        // Send POST request to register user
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // Check if status code is 201 (Created) which indicates successful registration
        if (response.statusCode() == 201) {
            System.out.println("User Registered Successfully!");
            return true;
        } else {
            System.out.println("Failed to Register User. Status Code: " + response.statusCode());
            return false;
        }

    } catch (UsernameTakenException e) {
        // This catch is redundant since this exception will be handled by the caller
        throw e;
    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}

// Custom exception for username taken
public static class UsernameTakenException extends Exception {
    public UsernameTakenException(String message) {
        super(message);
    }
}

    public static boolean isUsernameTaken(String username) {
        try {
            // URL of the REST endpoint for fetching user data
            String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/users/";

            // Create an HTTP client and request to fetch existing users
            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            // Send GET request to fetch user data
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                String responseBody = response.body();
                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONArray items = jsonResponse.getJSONArray("items");

                // Check if the username is already present in the list of users
                for (int i = 0; i < items.length(); i++) {
                    JSONObject user = items.getJSONObject(i);
                    if (user.getString("username").equalsIgnoreCase(username)) {
                        return true; // Username is already taken
                    }
                }
            } else {
                System.out.println("Failed to retrieve users. Status code: " + response.statusCode());
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return false; // Username is not taken
    }
}