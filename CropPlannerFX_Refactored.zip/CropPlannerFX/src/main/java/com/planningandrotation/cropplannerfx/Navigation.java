/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import java.io.IOException;
import java.util.function.Consumer;
import javafx.application.Platform;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.stage.Stage;

/**
 *
 * @author djlan
 */
public class Navigation {

    private static Stage mainStage;

    public static void setMainStage(Stage stage) {
        mainStage = stage;
    }

    public static void switchScene(String fxml) {
        try {
            System.out.println("Switching to scene: " + fxml); // Debugging statement

            FXMLLoader loader = new FXMLLoader(Navigation.class.getResource("/com/planningandrotation/cropplannerfx/" + fxml + ".fxml"));
            Parent root = loader.load();

            // Get the controller for the new scene
            Object controller = loader.getController();
            if (controller instanceof App.HasMainStage) {
                ((App.HasMainStage) controller).setMainStage(mainStage);
            }

            // Store the current window state
            boolean wasFullscreen = mainStage.isFullScreen();
            boolean wasMaximized = mainStage.isMaximized();

            // Set the new scene on the main stage
            Scene scene = new Scene(root);
            mainStage.setScene(scene);

            // Restore window properties after setting the new scene
            Platform.runLater(() -> {
                try {
                    if (wasFullscreen) {
                        mainStage.setFullScreen(true);
                    } else if (wasMaximized) {
                        mainStage.setMaximized(true);
                    } else {
                        // Set specific size depending on the current page
                        if (fxml.equals("signIn") || fxml.equals("register")) {
                            mainStage.setWidth(500);
                            mainStage.setHeight(550);
                        } else {
                            mainStage.setWidth(900);
                            mainStage.setHeight(650);
                        }
                    }
                } catch (Exception e) {
                    System.err.println("Error restoring window properties: " + e.getMessage());
                    e.printStackTrace();
                }
            });

            mainStage.show();

        } catch (IOException e) {
            System.err.println("Error loading scene: " + fxml);
            e.printStackTrace();
        }
    }

    // New method to switch scene and allow controller configuration
    public static <T> void switchScene(String fxml, Consumer<T> controllerConsumer) {
        try {
            System.out.println("Switching to scene with controller configuration: " + fxml); // Debugging statement

            FXMLLoader loader = new FXMLLoader(Navigation.class.getResource("/com/planningandrotation/cropplannerfx/" + fxml + ".fxml"));
            Parent root = loader.load();

            // Get the controller for the new scene
            T controller = loader.getController();
            controllerConsumer.accept(controller);

            if (controller instanceof App.HasMainStage) {
                ((App.HasMainStage) controller).setMainStage(mainStage);
            }

            // Store the current window state
            boolean wasFullscreen = mainStage.isFullScreen();
            boolean wasMaximized = mainStage.isMaximized();

            // Set the new scene on the main stage
            Scene scene = new Scene(root);
            mainStage.setScene(scene);

            Platform.runLater(() -> {
                try {
                    if (wasFullscreen) {
                        mainStage.setFullScreen(true);
                    } else if (wasMaximized) {
                        mainStage.setMaximized(true);
                    } else {
                        mainStage.setWidth(900);
                        mainStage.setHeight(650);
                    }
                } catch (Exception e) {
                    System.err.println("Error restoring window properties after controller configuration: " + e.getMessage());
                    e.printStackTrace();
                }
            });

            mainStage.show();

        } catch (IOException e) {
            System.err.println("Error loading scene with controller configuration: " + fxml);
            e.printStackTrace();
        }
    }
}
