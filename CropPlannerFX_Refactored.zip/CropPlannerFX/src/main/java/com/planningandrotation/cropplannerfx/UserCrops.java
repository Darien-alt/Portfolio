/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import org.json.JSONArray;
import org.json.JSONObject;

import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;

public class UserCrops {

    private final int loggedInUserID;
    private int isDeleted;
    private int isHarvested;

    public UserCrops(int loggedInUserID) {
        this.loggedInUserID = loggedInUserID;
    }

    // Method to save the crop for the user
    public boolean saveCropForUser(Crop crop) {
    try {
        // Define the REST API endpoint for saving the crop data
        String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/user_crops/";

        // Create a new JSON object with crop data
        JSONObject cropDataJson = new JSONObject();
        cropDataJson.put("user_id", UserSession.getInstance().getUserId());  // Get the logged-in user ID
        cropDataJson.put("crop_name", crop.getName());
        cropDataJson.put("variety", crop.getVariety());  // Changed from "varieties" to "variety"
        cropDataJson.put("planting_date", crop.getPlantingDate());
        cropDataJson.put("harvest_date", crop.getHarvestDate());  // New field for harvest date
        cropDataJson.put("fertilization_details", crop.getFertilizationDetails());
        cropDataJson.put("care_notes", crop.getCareNotes());
        cropDataJson.put("avg_price", crop.getAvgMarketPriceLb());
        cropDataJson.put("avg_yield", crop.getAvgYield());

        // Get current timestamp in ISO-8601 format
        String currentTimestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
        cropDataJson.put("created_at", currentTimestamp);
        cropDataJson.put("is_deleted", 0);  // Set is_deleted to 0 by default
        cropDataJson.put("is_harvested", crop.getIsHarvested()); // Add new field for is_harvested

        // Create the HTTP client
        HttpClient client = HttpClient.newHttpClient();

        // Create the HTTP POST request
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .POST(HttpRequest.BodyPublishers.ofString(cropDataJson.toString()))
                .build();

        // Send the request
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // Check the response status
        if (response.statusCode() == 201) {
            System.out.println("Crop data successfully saved.");
            return true;  // Indicates success
        } else {
            System.out.println("Failed to save crop data. Response code: " + response.statusCode());
            System.out.println("Response body: " + response.body());
            return false;  // Indicates failure
        }
    } catch (Exception e) {
        e.printStackTrace();
        return false;  // Indicates an error occurred
    }
}

    
    // Method to fetch the user's crops
public List<Crop> fetchUserCrops() {
    List<Crop> crops = new ArrayList<>();
    try {
        int loggedInUserId = UserSession.getInstance().getUserId(); // Get the logged-in user's ID
        String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/user_crops/?user_id=" + loggedInUserId;

        HttpClient client = HttpClient.newHttpClient();
        boolean hasMore = true;

        while (url != null && hasMore) {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            if (response.statusCode() == 200) {
                String responseBody = response.body();
                System.out.println("Fetched data response body: " + responseBody); // Debug output

                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONArray items = jsonResponse.getJSONArray("items");

                for (int i = 0; i < items.length(); i++) {
                    JSONObject cropJson = items.getJSONObject(i);

                    // Check the user_id to ensure the crop belongs to the logged-in user
                    int userId = cropJson.getInt("user_id");
                    if (userId != loggedInUserId) {
                        continue; // Skip crops that do not belong to the logged-in user
                    }

                    // Get the 'is_deleted' and 'is_harvested' values. Default to 0 if not present.
                    int isDeleted = cropJson.optInt("is_deleted", 0);
                    int isHarvested = cropJson.optInt("is_harvested", 0); // Fetch the is_harvested value

                    // Only add crops that are not marked as deleted.
                    if (isDeleted == 0) {
                        String name = cropJson.optString("crop_name", "Unknown");
                        String variety = cropJson.optString("variety", "Unknown");
                        String plantingDate = cropJson.optString("planting_date", "Unknown");
                        String harvestDate = cropJson.optString("harvest_date", "Unknown");
                        String fertilizationDetails = cropJson.optString("fertilization_details", "Unknown");
                        String careNotes = cropJson.optString("care_notes", "Unknown");
                        double avgMarketPriceLb = cropJson.optDouble("avg_price", 0.0);
                        String avgYield = cropJson.optString("avg_yield", "Unknown");
                        String soilTemp = cropJson.optString("soil_temp", "Unknown");
                        String soilMoisture = cropJson.optString("soil_moisture", "Unknown");
                        String soilPH = cropJson.optString("soil_ph", "Unknown");
                        String region = cropJson.optString("region", "Unknown");
                        String imagePath = cropJson.optString("image_path", null);
                        int userCropId = cropJson.optInt("user_crop_id", 0);
                        String harvestedYield = cropJson.optString("harvested_yield", null);
                        JSONArray links = cropJson.optJSONArray("links");
                        double productionCostLb = cropJson.optDouble("production_cost_lb", 0.0);
                        String createdAt = cropJson.optString("created_at", null); // Fetch created_at

                        // Debug output to ensure created_at is being read properly
                        System.out.println("Fetched created_at value for crop '" + name + "': " + createdAt);

                        // Create and add Crop object with all required parameters, including createdAt
                        crops.add(new Crop(
                                name,
                                variety,
                                plantingDate,
                                harvestDate,
                                fertilizationDetails,
                                careNotes,
                                avgMarketPriceLb,
                                avgYield,
                                soilTemp,
                                soilMoisture,
                                soilPH,
                                region,
                                imagePath,
                                userCropId,
                                isDeleted,
                                isHarvested,
                                harvestedYield,
                                links,
                                productionCostLb,
                                createdAt
                        ));
                    }
                }

                // Check if there are more pages to fetch
                hasMore = jsonResponse.has("hasMore") && jsonResponse.getBoolean("hasMore");
                url = null;

                // Update the URL if more data is available
                if (hasMore) {
                    JSONArray links = jsonResponse.getJSONArray("links");
                    for (int i = 0; i < links.length(); i++) {
                        JSONObject link = links.getJSONObject(i);
                        if (link.getString("rel").equals("next")) {
                            url = link.getString("href");
                            break;
                        }
                    }
                }
            } else {
                System.out.println("Failed to fetch crop data. Response code: " + response.statusCode());
                hasMore = false; // Stop fetching if the response is unsuccessful
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }
    return crops;
}

    // Method to mark a crop as deleted
    public boolean markCropAsDeleted(Crop crop) {
        try {
            // Use the provided link to get the correct URL for this crop
            String url = crop.getLink("self");

            // Get the current logged-in user ID from UserSession
            int userId = UserSession.getInstance().getUserId();

            // Create JSON object to update all fields, including is_deleted
            JSONObject updateDataJson = new JSONObject();
            updateDataJson.put("user_crop_id", crop.getUserCropId());  // Adding user_crop_id (if it's required by your DB schema)
            updateDataJson.put("user_id", userId);  // Use the logged-in user's ID
            updateDataJson.put("crop_name", crop.getName());
            updateDataJson.put("variety", crop.getVariety());
            updateDataJson.put("planting_date", crop.getPlantingDate());
            updateDataJson.put("harvest_date", crop.getHarvestDate()); // Added harvest date
            updateDataJson.put("fertilization_details", crop.getFertilizationDetails());
            updateDataJson.put("care_notes", crop.getCareNotes());
            updateDataJson.put("avg_price", crop.getAvgMarketPriceLb());
            updateDataJson.put("avg_yield", crop.getAvgYield());
            updateDataJson.put("is_deleted", 1);  // Set is_deleted to 1

            HttpClient client = HttpClient.newHttpClient();
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .PUT(HttpRequest.BodyPublishers.ofString(updateDataJson.toString()))
                    .build();

            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Print response details for debugging
            System.out.println("Response code: " + response.statusCode());
            System.out.println("Request: " + request);

            return response.statusCode() == 200 || response.statusCode() == 204;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    // Method to get the is_deleted value for a crop
    public int getIsDeleted() {
        return isDeleted;
    }
    
    public boolean markCropAsHarvested(Crop crop, String harvestedYield) {
    try {
        // Use the provided link to get the correct URL for this crop
        String url = crop.getLink("self");

        // Get the current logged-in user ID from UserSession
        int userId = UserSession.getInstance().getUserId();

        // Create a new JSON object with all crop data, including updates
        JSONObject updateDataJson = new JSONObject();
        updateDataJson.put("user_crop_id", crop.getUserCropId());  // Adding user_crop_id (if it's required by your DB schema)
        updateDataJson.put("user_id", userId);  // Use the logged-in user's ID
        updateDataJson.put("crop_name", crop.getName());
        updateDataJson.put("variety", crop.getVariety());
        updateDataJson.put("planting_date", crop.getPlantingDate());
        updateDataJson.put("harvest_date", crop.getHarvestDate()); // Add harvest date if it's available
        updateDataJson.put("fertilization_details", crop.getFertilizationDetails());
        updateDataJson.put("care_notes", crop.getCareNotes());
        updateDataJson.put("avg_price", crop.getAvgMarketPriceLb());
        updateDataJson.put("avg_yield", crop.getAvgYield());
        updateDataJson.put("is_deleted", crop.getIsDeleted());  // Include the current is_deleted status
        updateDataJson.put("is_harvested", 1);  // Set is_harvested to 1
        updateDataJson.put("harvested_yield", harvestedYield);  // Store the harvested yield

        // Create the HTTP client
        HttpClient client = HttpClient.newHttpClient();

        // Create the HTTP PUT request to update the crop data
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(url))
                .header("Content-Type", "application/json")
                .PUT(HttpRequest.BodyPublishers.ofString(updateDataJson.toString()))
                .build();

        // Send the request
        HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

        // Debug: Print response status and body
        System.out.println("Response Status Code: " + response.statusCode());
        System.out.println("Response Body: " + response.body());

        // Check the response status (consider both 200 and 204 as successful)
        return response.statusCode() == 200 || response.statusCode() == 204;

    } catch (Exception e) {
        e.printStackTrace();
        return false;
    }
}
    
    public int getIsHarvested() {
        return isHarvested;
    }
    
}
