package com.planningandrotation.cropplannerfx.ui;


import javafx.application.Platform;
import javafx.fxml.FXML;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.control.Alert;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;

public class SecondaryController {

    @FXML
    private TextField usernameField;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button signInButton;

    @FXML
    private void handleSignIn() {
        String username = usernameField.getText().trim();
        String password = passwordField.getText().trim();

        // Call authenticateUser to verify the credentials and retrieve userID if valid
        int userID = UserVerification.verifyUser(username, password);

        if (userID != -1) {  // If the userID is not -1, it means verification was successful
            Alert alert = new Alert(Alert.AlertType.INFORMATION);
            alert.setTitle("Sign In");
            alert.setHeaderText(null);
            alert.setContentText("Sign In Successful!");
            alert.showAndWait();

            // Store the userID and username in UserSession for session data
            UserSession session = UserSession.getInstance();
            session.setUserId(userID);
            session.setUsername(username);

            // Proceed to the primary panel
            Navigation.switchScene("primary");
        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Sign In");
            alert.setHeaderText(null);

            // Check if the username is taken by calling UserRegistration's isUsernameTaken method
            if (UserRegistration.isUsernameTaken(username)) {
                alert.setContentText("Invalid password for the given username.");
            } else {
                alert.setContentText("Invalid username or password.");
            }

            alert.showAndWait();
        }
    }

    @FXML
    private void initialize() {
        // Set the cursor to the username field by default
        Platform.runLater(() -> usernameField.requestFocus());

        // Combine all key events for usernameField
        usernameField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                handleSignIn();
            } else if (event.getCode() == KeyCode.TAB) {
                passwordField.requestFocus();
                event.consume();  // Prevent default tab behavior
            }
        });

        // Combine all key events for passwordField
        passwordField.setOnKeyPressed(event -> {
            if (event.getCode() == KeyCode.ENTER) {
                handleSignIn();
            } else if (event.getCode() == KeyCode.TAB) {
                signInButton.requestFocus();
                event.consume();  // Prevent default tab behavior
            }
        });
    }

    @FXML
    private void toRegister() {
        Navigation.switchScene("register");
    }
}