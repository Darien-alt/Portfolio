/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

/**
 * FXML Controller class
 *
 * @author djlan
 */
public class CropRecommendationsController implements App.HasMainStage {

    @FXML
    private VBox recommendationsBox; // Reference to the VBox in the FXML

    private Stage mainStage;
    
    private Crop selectedCrop;
    
    private UserInputForm userInputForm;

    @Override
public void setMainStage(Stage mainStage) {
    this.mainStage = mainStage;

    if (userInputForm != null) {
        // Use the existing userInputForm to repopulate recommendations
        recommendCrops(userInputForm);
    } else {
        System.err.println("Error: UserInputForm is not set. Cannot proceed with recommending crops.");
    }
}

public void recommendCrops(UserInputForm userInputForm) {
    // Create an instance of CropRecommendationLogic
    CropRecommendationLogic cropRecommendationLogic = new CropRecommendationLogic(recommendationsBox, mainStage);

    // Fetch the list of recommended crops
    List<Crop> recommendedCrops = cropRecommendationLogic.recommendCrops(userInputForm);
    System.out.println("Number of recommended crops: " + recommendedCrops.size());

    // Use the list of recommended crops to populate the VBox
    cropRecommendationLogic.populateRecommendations(recommendedCrops, userInputForm);
}

    @FXML
    private void backToSensor() {
        Navigation.switchScene("addCropLocation");
    }
    
    @FXML
    private void handleAddCrop() {
        if (selectedCrop != null) {
            UserCrops userCrops = new UserCrops(UserSession.getInstance().getUserId());
            boolean success = userCrops.saveCropForUser(selectedCrop);
            if (success) {
                System.out.println("Crop saved successfully!");
            } else {
                System.out.println("Failed to save crop.");
            }
        }
    }

    public void setSelectedCrop(Crop crop) {
        this.selectedCrop = crop;
    }
    
     // Setter method for UserInputForm
    public void setUserInputForm(UserInputForm userInputForm) {
        this.userInputForm = userInputForm;
    }

    @FXML
    private void initialize() {
        // Use userInputForm data if needed here
        if (userInputForm != null) {
            // Process or display data from userInputForm
            System.out.println("User Data: " + userInputForm.getCity());
        }
    }

}
