/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/javafx/FXMLController.java to edit this template
 */
package com.planningandrotation.cropplannerfx;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.VBox;
import org.json.JSONObject;
import java.net.http.HttpClient;
import java.util.List;
import java.util.Optional;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.control.TextInputDialog;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;

/**
 * FXML Controller class
 *
 * @author djlan
 */

public class ManageCropsController {

    @FXML
    private VBox manageCropsBox;

    @FXML
    private Button backButton;

    private final UserCrops userCrops;

    public ManageCropsController() {
        // Assuming loggedInUserID is available globally
        int loggedInUserID = UserSession.getInstance().getUserId();
        userCrops = new UserCrops(loggedInUserID);
    }

    @FXML
    public void initialize() {
        populateManageCrops();
    }

    @FXML
    private void backToHome() {
        Navigation.switchScene("primary");
    }

    private void populateManageCrops() {
    manageCropsBox.getChildren().clear(); // Clear any existing nodes

    // Fetch crops for the logged-in user, ensuring it is always a fresh list
    List<Crop> freshCrops = userCrops.fetchUserCrops();

    freshCrops.stream()
            .filter(crop -> {
                System.out.println("Filtering crop: " + crop.getName() + ", is_harvested: " + crop.getIsHarvested() + ", is_deleted: " + crop.getIsDeleted());
                return crop.getIsDeleted() == 0 && crop.getIsHarvested() == 0; // Only include crops that are not deleted and not harvested
            })
            .forEach(crop -> {
                System.out.println("Including crop: " + crop.getName()); // Debugging statement

                // Create an HBox to hold the crop details, delete button, and harvest button
                HBox cropHBox = new HBox(15);
                cropHBox.setPadding(new Insets(10));
                cropHBox.setAlignment(Pos.CENTER_LEFT);
                cropHBox.setStyle("-fx-border-color: lightgrey; -fx-border-width: 1; -fx-border-radius: 5; -fx-background-color: #F9F9F9;");
                cropHBox.setMaxWidth(Double.MAX_VALUE); // Allow the HBox to take the full width
                cropHBox.setPrefWidth(manageCropsBox.getWidth()); // Set preferred width to match the parent box width

                // Ensure HBox expands properly
                HBox.setHgrow(cropHBox, Priority.ALWAYS);

                // Create a VBox for the crop details
                VBox cropDetailsBox = new VBox(5);
                cropDetailsBox.setAlignment(Pos.CENTER_LEFT);
                cropDetailsBox.setMaxWidth(Double.MAX_VALUE); // Allow the VBox to take the full width
                cropDetailsBox.setPrefWidth(600); // Provide enough space for content

                // Create labels for each piece of crop information
                Label cropLabel = new Label(
                        String.format("Name: %s\nVariety: %s\nPlanting Date: %s\nHarvest Date: %s\nFertilization: %s\nCare Notes: %s\nAvg Price: %s\nAvg Yield: %s",
                                crop.getName(), crop.getVariety(), crop.getPlantingDate(), crop.getHarvestDate(), crop.getFertilizationDetails(), crop.getCareNotes(), crop.getAvgMarketPriceLb(), crop.getAvgYield()
                        )
                );

                // Set minimum height to ensure all lines are visible
                cropLabel.setMinHeight(140); // Adjust this value as needed to fit all lines
                cropLabel.setWrapText(true);
                cropLabel.setMaxWidth(600); // Set a reasonable maximum width
                cropLabel.setPrefWidth(600); // Make sure it takes a reasonable width to display the content

                // Add crop label to the details box
                cropDetailsBox.getChildren().add(cropLabel);

                // Create a delete button for each crop
                Button deleteButton = new Button("Delete");
                deleteButton.setMinWidth(80);
                deleteButton.setMaxWidth(80);
                deleteButton.setStyle("-fx-background-color: #ff4545ff;");
                deleteButton.setOnAction(event -> {
                    // Create a confirmation alert
                    Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
                    confirmationAlert.setTitle("Delete Confirmation");
                    confirmationAlert.setHeaderText("Are you sure you want to delete this crop?");
                    confirmationAlert.setContentText("Crop Name: " + crop.getName() + " - Variety: " + crop.getVariety());

                    // Show the confirmation alert and wait for user response
                    confirmationAlert.showAndWait().ifPresent(result -> {
                        if (result == ButtonType.OK) {
                            // If user confirms, proceed with deletion
                            boolean success = userCrops.markCropAsDeleted(crop);
                            if (success) {
                                // Re-populate the crops list after a successful delete
                                populateManageCrops();
                            } else {
                                System.out.println("Failed to delete crop.");
                            }
                        }
                    });
                });

                // Create a harvest button for each crop
                Button harvestButton = new Button("Harvest");
                harvestButton.setMinWidth(80);
                harvestButton.setMaxWidth(80);
                harvestButton.setStyle("-fx-background-color: #93C57D;");
                harvestButton.setOnAction(event -> {
                    // Prompt the user to enter the harvested yield
                    TextInputDialog yieldDialog = new TextInputDialog();
                    yieldDialog.setTitle("Harvest Crop");
                    yieldDialog.setHeaderText("Enter harvested yield for this crop");
                    yieldDialog.setContentText("Harvested Yield:");

                    Optional<String> yieldResult = yieldDialog.showAndWait();
                    if (yieldResult.isPresent()) {
                        String harvestedYield = yieldResult.get();
                        // Create a confirmation alert
                        Alert confirmationAlert = new Alert(Alert.AlertType.CONFIRMATION);
                        confirmationAlert.setTitle("Harvest Confirmation");
                        confirmationAlert.setHeaderText("Are you sure you want to mark this crop as harvested?");
                        confirmationAlert.setContentText("Crop Name: " + crop.getName() + " - Variety: " + crop.getVariety() + "\nHarvested Yield: " + harvestedYield);

                        // Show the confirmation alert and wait for user response
                        confirmationAlert.showAndWait().ifPresent(result -> {
                            if (result == ButtonType.OK) {
                                // If user confirms, proceed with harvesting
                                boolean success = userCrops.markCropAsHarvested(crop, harvestedYield);
                                if (success) {
                                    // Force update the crop to reflect harvested status
                                    crop.setIsHarvested(1);
                                    populateManageCrops(); // Re-populate the crops list after a successful harvest
                                } else {
                                    System.out.println("Failed to mark crop as harvested.");
                                }
                            }
                        });
                    }
                });

                // Add crop details, delete button, and harvest button to the HBox
                cropHBox.getChildren().addAll(cropDetailsBox, deleteButton, harvestButton);
                manageCropsBox.getChildren().add(cropHBox); // Add each HBox to the main container
            });
}

}
