package com.planningandrotation.cropplannerfx.logic;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

import org.json.JSONObject;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;

public class UserInputForm {
    private int userID;
    private String state;
    private String city;
    private double acreage;
    private Double soilMoisture;
    private Double soilTemperature;
    private Double soilPH;
    private String createdAt;
    private double minProfitThreshold = 500;

    // Constructor
    public UserInputForm(int userID, String state, String city, double acreage) {
        this.userID = userID;
        this.state = state;
        this.city = city;
        this.acreage = acreage;
        this.minProfitThreshold = minProfitThreshold;
    }
    
    public UserInputForm(int userId) {
        this.userID = userId;
    }
    
    // Getters and setters for all fields
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCity() {
        return capitalizeWords(city);
    }

    public void setCity(String city) {
        this.city = city;
    }

    public double getAcreage() {
        return acreage;
    }

    public void setAcreage(double acreage) {
        this.acreage = acreage;
    }

    public Double getSoilMoisture() {
        return soilMoisture;
    }

    public void setSoilMoisture(Double soilMoisture) {
        this.soilMoisture = soilMoisture;
    }

    public Double getSoilTemperature() {
        return soilTemperature;
    }

    public void setSoilTemperature(Double soilTemperature) {
        this.soilTemperature = soilTemperature;
    }

    public Double getSoilPH() {
        return soilPH;
    }

    public void setSoilPH(Double soilPH) {
        this.soilPH = soilPH;
    }

    public int getUserID() {
        return userID;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }
    
    public double getMinProfitThreshold() {
        return minProfitThreshold;
    }

    public void setMinProfitThreshold(double minProfitThreshold) {
        this.minProfitThreshold = minProfitThreshold;
    }

    // Method to save user data to the database via REST API
    public static boolean saveUserData(UserInputForm userInputForm) {
        try {
            // Define the REST API endpoint where you want to save the data
            String url = "https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/user_input/";

            // Create a new JSON object with user input data
            JSONObject userInputJson = new JSONObject();
            userInputJson.put("user_id", userInputForm.getUserID());
            userInputJson.put("state", userInputForm.getState());
            userInputJson.put("city", userInputForm.getCity());
            userInputJson.put("acreage", userInputForm.getAcreage());

            if (userInputForm.getSoilMoisture() != null) {
                userInputJson.put("soil_moisture", userInputForm.getSoilMoisture());
            }
            if (userInputForm.getSoilTemperature() != null) {
                userInputJson.put("soil_temperature", userInputForm.getSoilTemperature());
            }
            if (userInputForm.getSoilPH() != null) {
                userInputJson.put("soil_ph", userInputForm.getSoilPH());
            }

            // Get current timestamp in ISO-8601 format
            String currentTimestamp = LocalDateTime.now().format(DateTimeFormatter.ISO_LOCAL_DATE_TIME);
            userInputJson.put("created_at", currentTimestamp);

            // Create the HTTP client
            HttpClient client = HttpClient.newHttpClient();

            // Create the HTTP POST request
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .POST(HttpRequest.BodyPublishers.ofString(userInputJson.toString()))
                    .build();

            // Send the request
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Check the response status
            if (response.statusCode() == 201) {
                System.out.println("User input data successfully saved.");
                return true;  // Indicates success
            } else {
                System.out.println("Failed to save user data. Response code: " + response.statusCode());
                System.out.println("Response body: " + response.body());  // Print response body for further details
                return false;  // Indicates failure
            }
        } catch (Exception e) {
            e.printStackTrace();
            return false;  // Indicates an error occurred
        }
    }

    // Utility method to capitalize each word
    private String capitalizeWords(String str) {
        if (str == null || str.isEmpty()) {
            return str;
        }
        String[] words = str.split("\\s+");
        StringBuilder capitalized = new StringBuilder();
        for (String word : words) {
            if (word.length() > 0) {
                capitalized.append(Character.toUpperCase(word.charAt(0)))
                           .append(word.substring(1))
                           .append(" ");
            }
        }
        return capitalized.toString().trim();
    }
    
    public static List<UserInputForm> fetchSoilSensorData(int userId) {
    List<UserInputForm> sensorDataList = new ArrayList<>();

    try {
        // Properly construct the URL with URL-encoded user_id parameter
        String url = String.format("https://gb5d4ffbaa818f7-cropdb.adb.us-chicago-1.oraclecloudapps.com/ords/admin/user_input/?user_id=%d", userId);
        
        HttpClient client = HttpClient.newHttpClient();
        boolean hasMore = true;

        while (url != null && hasMore) {
            // Create the HTTP GET request
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(url))
                    .header("Content-Type", "application/json")
                    .GET()
                    .build();

            // Send the request
            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

            // Check if response is successful
            if (response.statusCode() == 200) {
                System.out.println("Soil sensor data fetched successfully.");
                String responseBody = response.body();

                // Parse the JSON response
                JSONObject jsonResponse = new JSONObject(responseBody);
                JSONArray items = jsonResponse.getJSONArray("items");

                // Loop through each item and create UserInputForm objects
                for (int i = 0; i < items.length(); i++) {
                    JSONObject dataJson = items.getJSONObject(i);

                    // Extract data fields
                    int fetchedUserId = dataJson.getInt("user_id");
                    if (fetchedUserId != userId) {
                        continue;  // Skip any data that doesn't match the current user_id
                    }

                    Double soilMoisture = dataJson.has("soil_moisture") && !dataJson.isNull("soil_moisture") ? dataJson.getDouble("soil_moisture") : null;
                    Double soilTemperature = dataJson.has("soil_temperature") && !dataJson.isNull("soil_temperature") ? dataJson.getDouble("soil_temperature") : null;
                    Double soilPH = dataJson.has("soil_ph") && !dataJson.isNull("soil_ph") ? dataJson.getDouble("soil_ph") : null;
                    String createdAt = dataJson.has("created_at") && !dataJson.isNull("created_at") ? dataJson.getString("created_at") : null;

                    // Only proceed if we have at least one valid sensor reading (skip if all are null)
                    if (soilMoisture != null || soilTemperature != null || soilPH != null) {
                        UserInputForm userInput = new UserInputForm(userId);
                        userInput.setSoilMoisture(soilMoisture);
                        userInput.setSoilTemperature(soilTemperature);
                        userInput.setSoilPH(soilPH);
                        userInput.setCreatedAt(createdAt);

                        sensorDataList.add(userInput);
                    }
                }

                // Check if there are more pages to fetch
                hasMore = jsonResponse.has("hasMore") && jsonResponse.getBoolean("hasMore");
                url = null;

                // Update the URL if more data is available
                if (hasMore) {
                    JSONArray links = jsonResponse.getJSONArray("links");
                    for (int i = 0; i < links.length(); i++) {
                        JSONObject link = links.getJSONObject(i);
                        if (link.getString("rel").equals("next")) {
                            url = link.getString("href");
                            break;
                        }
                    }
                }

            } else {
                System.out.println("Failed to fetch soil sensor data. Response code: " + response.statusCode());
                hasMore = false; // Stop fetching if the response is unsuccessful
            }
        }
    } catch (Exception e) {
        e.printStackTrace();
    }

    return sensorDataList;
}
    
    public String getRegion() {
    if (state != null) {
        switch (state.toUpperCase()) {
            // Tropical States
            case "AL":
            case "FL":
            case "GA":
            case "HI":
            case "LA":
            case "MS":
            case "SC":
                return "Tropical";

            // Arid States
            case "AZ":
            case "CA":
            case "NV":
            case "NM":
            case "TX":
                return "Arid";

            // Polar State
            case "AK":
                return "Polar";

            // Temperate States
            case "AR":
            case "CO":
            case "CT":
            case "DE":
            case "IL":
            case "IN":
            case "IA":
            case "KS":
            case "KY":
            case "ME":
            case "MD":
            case "MA":
            case "MI":
            case "MN":
            case "MO":
            case "MT":
            case "NE":
            case "NH":
            case "NJ":
            case "NY":
            case "NC":
            case "ND":
            case "OH":
            case "OK":
            case "OR":
            case "PA":
            case "RI":
            case "SD":
            case "TN":
            case "UT":
            case "VT":
            case "VA":
            case "WA":
            case "WV":
            case "WI":
            case "WY":
                return "Temperate";

            default:
                return "Unknown";
        }
    }
    return "Unknown";
}
    
}